<?php

namespace App\Http\Controllers;

use App\Mail\CheckOutMail;
use App\Order;
use App\Order_detail;
use Carbon\Carbon;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class CheckOutController extends Controller
{
    //
    function show()
    {
        return view('frontend.checkout');
    }
    function store(Request $request)
    {
        $request->validate(
            [
                'order_name' => 'required',
                'address' => 'required',
                'phone' => 'required',
            ],
            [
                'required' => ':attribute không được để trống',
                'min' => ':attribute có độ dài ít nhất :min ký tự',
                'max' => ':attribute có độ dài tối đa :max ký tự',
            ],
            [
                'order_name' => 'Họ tên',
                'address' => 'Địa chỉ',
                'phone' => 'Số điện thoại'
            ]
        );
        $data = array();
        $data['order_code'] = 'UNIMART-' . rand(0, 9999);
        $data['order_name'] = $request->input('order_name');
        $data['email'] = $request->input('email');
        $data['address'] = $request->input('address');
        $data['phone'] = $request->input('phone');
        $data['notes'] = $request->input('notes');
        $data['order_status'] = 0;
        $data['payment'] = $request->input('payment');
        $data['created_at'] = Carbon::now() ;
        $data['price_total']= Cart::total();
        $order_id = DB::table('orders')->insertGetId($data);

        foreach (Cart::content() as $content) {
            Order_detail::create([
                'order_id'=>$order_id,
                'product_id' => $content->id,
                'product_name' => $content->name,
                'product_price' => $content->price,
                'product_qty' => $content->qty,
                'color' => $content->options->color,
                'thumbnail' => $content->options->thumbnail,
                'total'=>$content->total
            ]);
        }
        Mail::to($request->input('email'))->send(new CheckOutMail);
        // $order = Order::find($order_id);
        Cart::destroy();
        // return view('frontend.thankyou');
        return redirect('thong-tin-don-hang');
    }
    function single(){
        // $order_id = Order::max('id');
        // $order = Order::find($order_id);
        // $order_detail = Order_detail::where('order_id',$order_id)->get();
        $order_time = Order::max('created_at');
        $order = Order::where('created_at',$order_time)->first();
        $order_detail = Order_detail::where('order_id',$order->id)->get();
        return view('frontend.thankyou',compact('order','order_detail'));
    }
}
