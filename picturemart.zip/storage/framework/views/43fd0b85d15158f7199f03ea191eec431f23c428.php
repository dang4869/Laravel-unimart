<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Blog</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="list-blog-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title">Blog</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('blog.detail',$post->slug)); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e(url($post->thumbnail)); ?>" alt="" >
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('blog.detail',$post->slug)); ?>" title="" class="title"><?php echo e($post->title); ?></a>
                                <span class="create-date"><?php echo e($post->created_at); ?></span>
                                <div class="desc"><?php echo $post->content; ?></div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm mới nhất</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $product_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e($item->imageUrl()); ?>" alt="" >
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="product-name"><?php echo e($item->product_name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item->price, 0, '','.')); ?>đ</span>
                                </div>
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="buy-now">Xem ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_blog_product" title="" class="thumb">
                        <img src="<?php echo e(asset('images/banner.png')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .pagination{
        display: flex;
        justify-content: center
    }
    .pagination li{
        font-size: 20px;
        padding: 10px 13px;
       background: wheat;
       margin-right: 5px;
       color: aliceblue
    }
    .active{
        background: tomato !important
    }
    .desc{
            height: 30px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/showblog.blade.php ENDPATH**/ ?>