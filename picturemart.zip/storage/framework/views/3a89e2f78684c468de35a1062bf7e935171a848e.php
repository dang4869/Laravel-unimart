<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix category-product-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Tìm kiếm</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <?php if($products->count()>0): ?>
            <div class="section" id="list-product-wp">
                <div class="section-head clearfix">
                    <h3 class="section-title fl-left">Kết quả Tìm kiếm : <?php echo e(request()->input('keyword')); ?></h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="?page=detail_product" title="" class="thumb">
                                <img src="<?php echo e(url($product->thumbnail)); ?>" style="height:160px">
                            </a>
                            <a href="?page=detail_product" title="" class="product-name"><?php echo e($product->product_name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($product->price, 0, '','.')); ?>đ</span>
                            </div>
                            <div class="action clearfix">
                                <a href="?page=cart" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm giỏ hàng</a>
                                <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="section" id="paging-wp">
                <div class="section-detail">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
            <?php else: ?>
                Không tìm được sản phẩm nào
            <?php endif; ?>

        </div>
        <div class="sidebar fl-left">
            <div class="section" id="category-product-wp">
                <div class="section-head">
                    <h3 class="section-title">Danh mục sản phẩm</h3>
                </div>
                <div class="secion-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('category.product', $item->slug)); ?>" title=""><?php echo e($item->category_name); ?></a>
                            <?php echo $__env->make('frontend.menu.child', ['item'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_product" title="" class="thumb">
                        <img src="public/images/banner.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .pagination{
        display: flex;
        justify-content: center
    }
    .pagination li{
        font-size: 20px;
        padding: 10px 13px;
       background: wheat;
       margin-right: 5px;
       color: aliceblue
    }
    .active{
        background: tomato !important
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/search.blade.php ENDPATH**/ ?>