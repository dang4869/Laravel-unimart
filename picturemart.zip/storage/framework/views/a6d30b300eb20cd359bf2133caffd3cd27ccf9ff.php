<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="clearfix detail-blog-page">
    <div class="wp-inner">
        <div class="secion" id="breadcrumb-wp">
            <div class="secion-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-content fl-right">
            <div class="section" id="detail-blog-wp">
                
                <div class="section-detail">
                    
                    <div class="detail">
                        <?php echo $contact->content; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm mới nhất</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $product_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e($item->imageUrl()); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="product-name"><?php echo e($item->product_name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item->price, 0, '','.')); ?>đ</span>
                                </div>
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="" class="buy-now">Xem ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="?page=detail_product" title="" class="thumb">
                        <img src="public/images/banner.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    h1{
        margin-bottom: 20px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/contact.blade.php ENDPATH**/ ?>