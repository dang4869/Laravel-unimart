<?php if($item->categoryChild->count()): ?>
    <ul class="sub-menu">
        <?php $__currentLoopData = $item->categoryChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('category.product', $item_sub->slug)); ?>" title=""><?php echo e($item_sub->category_name); ?></a>
                <?php if($item_sub->categoryChild->count()): ?>
                <?php echo $__env->make('frontend.menu.child', ['item'=>$item_sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/menu/child.blade.php ENDPATH**/ ?>