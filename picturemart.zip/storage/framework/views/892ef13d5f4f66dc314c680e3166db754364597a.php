<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách đơn hàng</h5>
            <div class="form-search form-inline">
                <form action="#" style="display: flex">
                    <input type="" class="form-control form-search mr-3" placeholder="Tìm kiếm" name="keyword" value="<?php echo e(request()->input('keyword')); ?>">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('admin/order/action')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <div class="analytic">
                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'loading'])); ?>" class="text-primary" >Đang xử lý<span class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'delivery'])); ?>" class="text-primary">Đang giao hàng<span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'success'])); ?>" class="text-primary">Hoàn thành<span class="text-muted">(<?php echo e($count[2]); ?>)</span></a>
                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'cancelled'])); ?>" class="text-primary">Đã hủy<span class="text-muted">(<?php echo e($count[3]); ?>)</span></a>
            </div>
            <div class="form-action form-inline py-3">
                <select class="form-control mr-1" id="" name="act">
                    <?php if($status == ''): ?>
                    <option>Chọn</option>
                    <option value="loading">Đang xử lý</option>
                    <option value="delivery">Đang giao hàng</option>
                    <option value="success">Hoàn thành</option>
                    <option value="cancelled">Đã hủy</option>
                    <option value="delete">Xóa đơn hàng</option>
                    <?php endif; ?>
                    <?php if($status == 'loading'): ?>
                    <option>Chọn</option>
                    <option value="delivery">Đang giao hàng</option>
                    <option value="success">Hoàn thành</option>
                    <option value="cancelled">Đã hủy</option>
                    <option value="delete">Xóa đơn hàng</option>
                    <?php endif; ?>
                    <?php if($status == 'delivery'): ?>
                    <option>Chọn</option>
                    <option value="loading">Đang xử lý</option>
                    <option value="success">Hoàn thành</option>
                    <option value="cancelled">Đã hủy</option>
                    <option value="delete">Xóa đơn hàng</option>
                    <?php endif; ?>
                    <?php if($status == 'success'): ?>
                    <option>Chọn</option>
                    <option value="loading">Đang xử lý</option>
                    <option value="delivery">Đang giao hàng</option>
                    <option value="cancelled">Đã hủy</option>
                    <option value="delete">Xóa đơn hàng</option>
                    <?php endif; ?>
                    <?php if($status == 'cancelled'): ?>
                    <option>Chọn</option>
                    <option value="loading">Khôi phục</option>
                    <option value="delete">Xóa đơn hàng</option>
                    <?php endif; ?>
                </select>
                <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
            </div>
            <table class="table table-striped table-checkall">
                <thead>
                    <tr>
                        <th>
                            <input type="checkbox" name="checkall">
                        </th>
                        <th scope="col">STT</th>
                        <th scope="col">Mã đơn hàng</th>
                        <th scope="col">Khách hàng</th>
                        <th scope="col">Số điện thoại</th>
                        <th scope="col">Giá trị</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Thời gian</th>
                        <th scope="col">Tác vụ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="list_check[]" value="<?php echo e($order->id); ?>">
                        </td>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($order->order_code); ?></td>
                        <td>
                            <?php echo e($order->order_name); ?>

                        </td>
                        <td> <?php echo e($order->phone); ?></td>
                        <td><?php echo e(number_format($order->price_total, 0,'','.')); ?>đ</td>
                        <?php if($order->order_status == 0): ?>
                        <td><span class="badge badge-warning">Đang xử lý</span></td>
                        <?php endif; ?>
                        <?php if($order->order_status == 1): ?>
                        <td><span class="badge badge-primary">Đang vận chuyển</span></td>
                        <?php endif; ?>
                        <?php if($order->order_status == 2): ?>
                        <td><span class="badge badge-success">Hoàn thành</span></td>
                        <?php endif; ?>
                        <?php if($order->order_status == 3): ?>
                        <td><span class="badge badge-danger">Đã hủy</span></td>
                        <?php endif; ?>
                        <td><?php echo e($order->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.order.detail', $order->id)); ?>" class="btn btn-primary btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Chi tiết đơn hàng"><i class="fa-solid fa-ellipsis"></i></i></a>
                            <a href="<?php echo e(route('admin.order.delete', $order->id)); ?>" class="btn btn-danger btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Xóa đơn hàng"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($orders->links()); ?>

        </div>
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/admin/order/list.blade.php ENDPATH**/ ?>