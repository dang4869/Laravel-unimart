<?php $__env->startSection('content'); ?>
    <style>
        .container-color {
            display: flex;
            margin-bottom: 10px
        }

        .form-check {
            border: 1px solid;
            padding: 5px 10px;
            margin-right: 10px;
        }

        h1,
        h2 {
            margin-bottom: 15px;
            font-weight: bold
        }

        ul {
            margin-bottom: 15px
        }

        .view-more-container a {
            text-transform: uppercase;
            font-weight: bold;
            font-size: 15px;
            color: #00483d;
        }
    </style>
    <div id="main-content-wp" class="clearfix detail-product-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="<?php echo e(url('trang-chu')); ?>" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="" >Chi tiết sản phẩm</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="detail-product-wp">
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <div class="section-detail clearfix">
                        <div class="thumb-wp fl-left" style="position: relative">
                            <a href="" title="" id="main-thumb">
                                <img id="zoom" src="<?php echo e($detail_product->imageUrl()); ?>"
                                    data-zoom-image="<?php echo e($detail_product->imageUrl()); ?>" />
                            </a>
                            <div id="list-thumb">
                                <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img_thumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href=""
                                        data-image="<?php echo e(url('public/uploads/gallery/' . $img_thumb->gallery_image)); ?>"
                                        data-zoom-image="<?php echo e(url('public/uploads/gallery/' . $img_thumb->gallery_image)); ?>"
                                        style="365px">
                                        <img id="zoom"
                                            src="<?php echo e(url('public/uploads/gallery/' . $img_thumb->gallery_image)); ?>" />
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="thumb-respon-wp fl-left">
                            
                        </div>
                        <div class="info fl-right">
                            <h3 class="product-name"><?php echo e($detail_product->product_name); ?></h3>
                            <div class="desc">
                                <?php echo $detail_product->product_detail; ?>

                            </div>
                            <div class="num-product">
                                <span class="title">Sản phẩm: </span>
                                
                                <span class="status">Còn hàng</span>
                            </div>
                            <p class="price"><?php echo e(number_format($detail_product->price, 0, '', '.')); ?>đ</p>
                            <form action="<?php echo e(route('cart.add', $detail_product->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <h4>Màu: </h4>
                                <div class="container-color">
                                    <?php $__currentLoopData = $color_amout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline color-item"
                                            style="background:<?php echo e($item->color_code); ?>; color:#ffff">
                                            <input class="d-none form-check-input" type="radio" name="color"
                                                id="<?php echo e($item->id); ?>" value="<?php echo e($item->name); ?>"
                                                style="height:18px; width:18px; vertical-align: middle;" <?php if($item->id == $min): ?>
                                                    checked
                                                <?php endif; ?>>

                                            <label class="form-check-label color-name" for="<?php echo e($item->id); ?>">
                                                <?php echo e($item->name); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div id="num-order-wp">
                                    <a title="" id="minus"><i class="fa fa-minus"></i></a>
                                    <input type="text" name="qty_num" value="1" id="num-order">
                                    <a title="" id="plus"><i class="fa fa-plus"></i></a>
                                </div>
                                <button title="Thêm giỏ hàng" class="add-cart" style="border: none">Thêm giỏ hàng</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="section" id="post-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Mô tả sản phẩm</h3>
                    </div>
                    <div class="section-detail">
                        <div class="detail" id="detail">
                            <?php echo $detail_product->product_desc; ?>

                        </div>
                        <div class="view-more-container" style="padding: 8px 10px;
                    text-align: center;">
                            <a href="javascript:;" type="button" id="viewMoreContent" onclick="viewMore()">Xem thêm</a>
                        </div>
                    </div>

                </div>
                <div class="section" id="same-category-wp">
                    <div class="section-head">
                        <h3 class="section-title">Cùng chuyên mục</h3>
                    </div>
                    <div class="section-detail">
                        <ul class="list-item">
                            <?php $__currentLoopData = $product_same; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $same): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($detail_product->id != $same->id): ?>
                                    <li>
                                        <a href="<?php echo e(route('product.detail', $same->slug)); ?>" title="" class="thumb">
                                            <img src="<?php echo e($same->imageUrl()); ?>">
                                        </a>
                                        <a href="<?php echo e(route('product.detail', $same->slug)); ?>" title=""
                                            class="product-name"><?php echo e($same->product_name); ?></a>
                                        <div class="price">
                                            <span class="new"><?php echo e(number_format($same->price, 0, '', '.')); ?>đ</span>
                                        </div>
                                        <div class="action clearfix">
                                            <a href="" title="" class="add-cart fl-left">Thêm giỏ hàng</a>
                                            <a href="" title="" class="buy-now fl-right">Mua ngay</a>
                                        </div>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="sidebar fl-left">
                <div class="section" id="category-product-wp">
                    <div class="section-head">
                        <h3 class="section-title">Danh mục sản phẩm</h3>
                    </div>
                    <div class="secion-detail">
                        <ul class="list-item">
                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('category.product', $item->slug)); ?>"
                                        title=""><?php echo e($item->category_name); ?></a>
                                    <?php echo $__env->make('frontend.menu.child', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="section" id="banner-wp">
                    <div class="section-detail">
                        <a href="" title="" class="thumb">
                            <img src="public/images/banner.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function viewMore() {
            if (document.getElementById("viewMoreContent").innerHTML == "Xem thêm") {
                document.getElementById("detail").style.height = "auto";
                document.getElementById("viewMoreContent").innerHTML = "Thu gọn";
            } else {
                document.getElementById("detail").style.height = "600px";
                document.getElementById("viewMoreContent").innerHTML = "Xem thêm";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/detail_product.blade.php ENDPATH**/ ?>