<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Thêm mới slider
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.slider.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="image">Hình ảnh</label>
                                    <input class="form-control-file" type="file" name="file" id="image">
                                </div>
                            </div>
                            <div class="col-md-4 mt-4">
                                <button type="submit" class="btn btn-primary">Thêm mới</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-header font-weight-bold">
                    Danh sách
                </div>
                <div id="delete_slider" data-url="<?php echo e(url('admin/slider/delete')); ?>">

                </div>
                <div id="update_slider" data-url="<?php echo e(url('admin/slider/update')); ?>">

                </div>
                <div class="card-body" id="slider-load" data-url="<?php echo e(url('admin/slider/select-slider')); ?>">
                    
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/admin/slider/list.blade.php ENDPATH**/ ?>