<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Thông tin khách hàng
            </div>
            <div class="card-body">
                <table class="table table-striped table-checkall">
                    <tbody><tr>
                        <td>Mã đơn hàng:</td>
                        <td colspan="2"><?php echo e($order->order_code); ?></td>
                    </tr>
                    <tr>
                        <td>Tên khách hàng:</td>
                        <td colspan="2"><?php echo e($order->order_name); ?></td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td colspan="2"><?php echo e($order->email); ?></td>
                    </tr>
                    <tr>
                        <td>Địa chỉ:</td>
                        <td colspan="2"><?php echo e($order->address); ?></td>
                    </tr>
                    <tr>
                        <td>Số điện thoại:</td>
                        <td colspan="2"><?php echo e($order->phone); ?></td>
                    </tr>
                    <tr>
                        <td>Ngày tạo:</td>
                        <td colspan="2"><?php echo e($order->created_at); ?></td>
                    </tr>
                    <tr>
                        <td>Ghi chú:</td>
                        <td colspan="2"><?php echo e($order->notes); ?></td>
                    </tr>
                    <tr>
                        <td>
                            <h6 class="text-uppercase font-weight-bold">Tổng tiền:</h6>
                        </td>
                        <td>
                            <h6 class="text-uppercase font-weight-bold"><?php echo e(number_format($order->price_total, 0, '', '.')); ?>đ</h6>
                        </td>
                    </tr>
                </tbody></table>
                <form class="form-inline" action="<?php echo e(route('admin.order.update', $order->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-2">
                      <label>Cập nhật trạng thái</label>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <select class="form-control" name="order_status">
                            <?php $__currentLoopData = $list_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($k); ?>" <?php if($order->order_status == $k): ?> selected
                            <?php endif; ?>><?php echo e($act); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 mr-3" value="status_update" name="status_update_btn">Cập nhật</button>
                  </form>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header font-weight-bold">
                Chi tiết đơn hàng
            </div>
            <div class="card-body">
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Ảnh</th>
                            <th scope="col">Tên sản phẩm</th>
                            <th scope="col">Giá</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Màu</th>
                            <th scope="col">Tổng</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td>
                                <img src="<?php echo e(url($item->thumbnail)); ?>" alt=""
                                    height="auto" width="80px">
                            </td>
                            <td><a href=""><?php echo e($item->product_name); ?></a></td>
                            <td><?php echo e(number_format($item->product_price, 0,'','.')); ?>đ</td>
                            <td><?php echo e($item->product_qty); ?></td>
                            <td><?php echo e($item->color); ?></td>
                            <td><?php echo e(number_format($item->total, 0, '','.')); ?>đ</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/admin/detailorder/show.blade.php ENDPATH**/ ?>