<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="cart-page">
    <div class="section" id="breadcrumb-wp">
        <div class="wp-inner">
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="<?php echo e(url('home/show')); ?>" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Giỏ hàng</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div id="wrapper" class="wp-inner clearfix">
        <form action="POST" data-url="<?php echo e(url('cart/update')); ?>" id="form-add">
            <?php echo csrf_field(); ?>
        <?php if(Cart::Count()>0): ?>
        <div class="section" id="info-cart-wp">
            <div class="section-detail table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <td>STT</td>
                            <td>Ảnh sản phẩm</td>
                            <td>Tên sản phẩm</td>
                            <td>Màu sản phẩm</td>
                            <td>Giá sản phẩm</td>
                            <td>Số lượng</td>
                            <td colspan="2">Thành tiền</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $t = 0;
                        ?>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $t++;
                        ?>
                        <tr>
                            <td><?php echo e($t); ?></td>
                            <td>
                                <a href="" title="" class="thumb">
                                    <img src="<?php echo e($row->options->thumbnail); ?>" alt="">
                                </a>
                            </td>
                            <td>
                                <a href="" title="" class="name-product"><?php echo e($row->name); ?></a>
                            </td>
                            <td><?php echo e($row->options->color); ?></td>
                            <td class="price-<?php echo e($row->rowId); ?>" name="price" data-price="<?php echo e($row->price); ?>"><?php echo e(number_format($row->price, 0, '','.')); ?>đ</td>
                            <td>
                                <input type="number" min="1" name="qty" value="<?php echo e($row->qty); ?>" class="num-order" data-id="<?php echo e($row->rowId); ?>">
                            </td>
                            <td id="sub-total-<?php echo e($row->rowId); ?>"><?php echo e(number_format($row->total, 0, '','.')); ?>đ</td>
                            <td>
                                <a href="<?php echo e(route('cart.remove', $row->rowId)); ?>" title="" class="del-product"><i class="fa fa-trash-o"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="7">
                                <div class="clearfix">
                                    <p id="total-price" class="fl-right" style="color: #ad0000">Tổng giá: <span><?php echo e(number_format(Cart::total(), 0,'','.')); ?></span>đ</p>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="7">
                                <div class="clearfix">
                                    <div class="fl-right">
                                        <a href="<?php echo e(url('thanh-toan')); ?>" title="" id="checkout-cart">Thanh toán</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <div class="section" id="action-cart-wp">
            <div class="section-detail">
                <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Nhập vào số lượng <span>0</span> để xóa sản phẩm khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.</p>
                <a href="<?php echo e(url('home/show')); ?>" title="" id="buy-more">Mua tiếp</a><br/>
                <a href="<?php echo e(url('cart/destroy')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
            </div>
        </div>
        <?php else: ?>
            <span>Hiện không có sản phẩm nào trong giỏ hàng</span>
        <?php endif; ?>
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/cart.blade.php ENDPATH**/ ?>