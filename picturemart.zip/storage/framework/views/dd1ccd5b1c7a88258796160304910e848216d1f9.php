<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="home-page clearfix">
    <div class="wp-inner">
        <div class="main-content fl-right">
            <div class="section" id="slider-wp">
                <div class="section-detail">
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <img src="<?php echo e(url($item->thumbnail)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="section" id="support-wp">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <div class="thumb">
                                <img src="<?php echo e(asset('images/icon-1.png')); ?>">
                            </div>
                            <h3 class="title">Miễn phí vận chuyển</h3>
                            <p class="desc">Tới tận tay khách hàng</p>
                        </li>
                        <li>
                            <div class="thumb">
                                <img src="<?php echo e(asset('images/icon-2.png')); ?>">
                            </div>
                            <h3 class="title">Tư vấn 24/7</h3>
                            <p class="desc">1900.9999</p>
                        </li>
                        <li>
                            <div class="thumb">
                                <img src="<?php echo e(asset('images/icon-3.png')); ?>">
                            </div>
                            <h3 class="title">Tiết kiệm hơn</h3>
                            <p class="desc">Với nhiều ưu đãi cực lớn</p>
                        </li>
                        <li>
                            <div class="thumb">
                                <img src="<?php echo e(asset('images/icon-4.png')); ?>">
                            </div>
                            <h3 class="title">Thanh toán nhanh</h3>
                            <p class="desc">Hỗ trợ nhiều hình thức</p>
                        </li>
                        <li>
                            <div class="thumb">
                                <img src="<?php echo e(asset('images/icon-5.png')); ?>">
                            </div>
                            <h3 class="title">Đặt hàng online</h3>
                            <p class="desc">Thao tác đơn giản</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="section" id="feature-product-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm nổi bật</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $product_featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('product.detail',$item_featured->slug)); ?>" title="" class="thumb">
                                <img src="<?php echo e($item_featured->imageUrl()); ?>" style="height: 170px">
                            </a>
                            <a href="<?php echo e(route('product.detail',$item_featured->slug)); ?>" title="" class="product-name"><?php echo e($item_featured->product_name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($item_featured->price, 0, '','.')); ?>đ</span>
                            </div>
                            <a href="<?php echo e(route('product.detail',$item_featured->slug)); ?>" class="position-absolute add-cart detail-cart hover-filled-slide-left">
                                <span><i class="fa-solid fa-eye"></i> Xem chi tiết</span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="list-product-wp">
                <div class="section-head">
                    <h3 class="section-title">Điện thoại</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <?php $__currentLoopData = $product_phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('product.detail',$phone->slug)); ?>" title="" class="thumb">
                                <img src="<?php echo e($phone->imageUrl()); ?>" style="width:100%">
                            </a>
                            <a href="<?php echo e(route('product.detail',$phone->slug)); ?>" title="" class="product-name" ><?php echo e($phone->product_name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($phone->price, 0, '','.')); ?>đ</span>
                                
                            </div>
                            <a href="<?php echo e(route('product.detail',$phone->slug)); ?>" class="position-absolute add-cart detail-cart hover-filled-slide-left">
                                <span><i class="fa-solid fa-eye"></i> Xem chi tiết</span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="list-product-wp">
                <div class="section-head">
                    <h3 class="section-title">Laptop</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <?php $__currentLoopData = $product_laptop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laptop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('product.detail',$laptop->slug)); ?>" title="" class="thumb">
                                <img src="<?php echo e($laptop->imageUrl()); ?>" style="width:100%; height:170px">
                            </a>
                            <a href="<?php echo e(route('product.detail',$laptop->slug)); ?>" title="" class="product-name"><?php echo e($laptop->product_name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($laptop->price, 0, '','.')); ?>đ</span>
                            </div>
                            <a href="<?php echo e(route('product.detail',$laptop->slug)); ?>" class="position-absolute add-cart detail-cart hover-filled-slide-left">
                                <span><i class="fa-solid fa-eye"></i> Xem chi tiết</span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="sidebar fl-left">
            <div class="section" id="category-product-wp">
                <div class="section-head">
                    <h3 class="section-title">Danh mục sản phẩm</h3>
                </div>
                <div class="secion-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('category.product', $item->slug)); ?>" title=""><?php echo e($item->category_name); ?></a>
                            <?php echo $__env->make('frontend.menu.child', ['item'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="section" id="selling-wp">
                <div class="section-head">
                    <h3 class="section-title">Sản phẩm mới nhất</h3>
                </div>
                <div class="section-detail">
                    <ul class="list-item">
                        <?php $__currentLoopData = $product_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="clearfix">
                            <a href="<?php echo e(route('product.detail',$item_new->slug)); ?>" title="" class="thumb fl-left">
                                <img src="<?php echo e($item_new->imageUrl()); ?>" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="<?php echo e(route('product.detail',$item_new->slug)); ?>" title="" class="product-name"><?php echo e($item_new->product_name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item_new->price, 0, '','.')); ?>đ</span>
                                </div>
                                <a href="<?php echo e(route('product.detail',$item_new->slug)); ?>" title="" class="buy-now">Xem ngay</a>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
            <div class="section" id="banner-wp">
                <div class="section-detail">
                    <a href="" title="" class="thumb">
                        <img src="<?php echo e(asset('images/banner.png')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/frontend/home.blade.php ENDPATH**/ ?>