<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách bài viết</h5>
                <div class="form-search form-inline">
                    <form action="#" style="display: flex">
                        <input type="" class="form-control form-search mr-3" placeholder="Tìm kiếm" name="keyword"
                            value="<?php echo e(request()->keyword); ?>">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/page/action')); ?>" method="">
                    
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name="act">
                            <option>Chọn</option>
                            <option value="delete">Xóa bài viết</option>
                        </select>
                        <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <th scope="col">
                                    <input name="checkall" type="checkbox">
                                </th>
                                <th scope="col">STT</th>
                                <th scope="col">Tiêu đề trang</th>
                                <th scope="col">slug</th>
                                <th scope="col">Ngày tạo</th>
                                <th scope="col">Tác vụ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="list_check[]" value="<?php echo e($page->id); ?>">
                                    </td>
                                    <td scope="row"><?php echo e(++$i); ?></td>
                                    <td><a href=""><?php echo e($page->name_page); ?></a></td>
                                    <td><?php echo e($page->slug); ?></td>
                                    <td><?php echo e($page->created_at); ?></td>
                                    <td><a href="<?php echo e(route('admin.page.edit',$page->id)); ?>" class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                            data-toggle="tooltip" data-placement="top" title="Cập nhật trang"><i
                                                class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(route('admin.page.delete', $page->id)); ?>"
                                            class="btn btn-danger btn-sm rounded-0  text-white" type="button"
                                            data-toggle="tooltip" data-placement="top" title="Xóa trang"><i
                                                class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($pages->links()); ?>

            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/admin/page/list.blade.php ENDPATH**/ ?>