<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold">
          Nhóm quyền
        </div>
        <div class="card-body">
                <div class="form-group">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $checked = in_array($role->name, $roles_ass) ? 'checked' : '' ;
                    ?>
                    <div class="form-check">
                        <input class="form-check-input" <?php echo e($checked); ?> type="checkbox" name="role[]" id="<?php echo e($role->id); ?>"
                            value="<?php echo e($role->id); ?>">
                        <label class="form-check-label" for="<?php echo e($role->id); ?>">
                            <?php echo e($role->name); ?>

                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp3\htdocs\unimart\resources\views/admin/user/role.blade.php ENDPATH**/ ?>