-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 17, 2022 lúc 02:36 PM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `laravel-unimart`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category_products`
--

CREATE TABLE `category_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_parent` bigint(20) NOT NULL,
  `category_status` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category_products`
--

INSERT INTO `category_products` (`id`, `category_name`, `slug`, `category_parent`, `category_status`, `created_at`, `updated_at`) VALUES
(28, 'Điện thoại', 'Điện-thoại', 0, 0, '2022-10-26 00:14:48', '2022-10-26 00:14:48'),
(30, 'Điện thoại Apple', 'dien-thoai-apple', 28, 0, '2022-10-27 06:09:26', '2022-10-28 20:45:55'),
(31, 'Laptop', 'laptop', 0, 0, '2022-10-28 05:31:36', '2022-10-28 05:31:36'),
(32, 'Laptop HP', 'laptop-hp', 31, 0, '2022-10-28 05:31:47', '2022-10-28 20:50:40'),
(33, 'Laptop Dell', 'laptop-dell', 31, 0, '2022-10-28 06:17:41', '2022-10-28 20:50:52'),
(36, 'Điện thoại Samsung', 'dien-thoai-samsung', 28, 0, '2022-10-28 06:31:53', '2022-10-28 20:46:15'),
(37, 'Điện thoại  Xiaomi', 'dien-thoai-xiaomi', 28, 0, '2022-10-28 06:33:50', '2022-10-28 20:47:25'),
(38, 'Phụ kiện', 'phu-kien', 0, 0, '2022-10-28 06:33:58', '2022-10-28 06:33:58'),
(39, 'Cáp , sạc điện thoại', 'cap-sac-dien-thoai', 38, 0, '2022-10-28 06:34:23', '2022-10-28 06:34:23'),
(40, 'Laptop Acer', 'laptop-acer', 31, 0, '2022-10-28 06:34:47', '2022-10-28 20:51:00'),
(41, 'Tablet', 'tablet', 0, 0, '2022-10-28 06:42:44', '2022-10-28 06:42:44'),
(42, 'Apple', 'apple', 41, 0, '2022-10-28 06:43:06', '2022-10-28 06:43:06'),
(43, 'Samsung', 'samsung', 41, 0, '2022-10-28 06:43:35', '2022-10-28 06:43:35'),
(44, 'Xiaomi', 'xiaomi', 41, 0, '2022-10-28 06:43:45', '2022-10-28 06:43:45'),
(45, 'Bàn phím', 'ban-phim', 38, 0, '2022-10-28 06:44:05', '2022-10-28 06:44:05'),
(46, 'Chuột', 'chuot', 38, 0, '2022-10-28 06:44:16', '2022-10-28 06:44:16'),
(47, 'Điện thoại  OPPO', 'dien-thoai-oppo', 28, 0, '2022-10-28 09:05:35', '2022-10-28 20:50:21'),
(48, 'Laptop Apple', 'laptop-apple', 31, 0, '2022-10-28 20:01:54', '2022-10-28 20:51:08'),
(49, 'Laptop Lenovo', 'laptop-lenovo', 31, 0, '2022-10-28 20:57:47', '2022-10-28 20:57:47');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gallerys`
--

CREATE TABLE `gallerys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gallery_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `gallerys`
--

INSERT INTO `gallerys` (`id`, `gallery_name`, `gallery_image`, `product_id`, `created_at`, `updated_at`) VALUES
(38, '4444476.44444.png', 'iphon14plus-168.iphon14plus-1.png', 15, '2022-10-30 01:16:02', '2022-10-30 05:11:45'),
(39, 'app-467.app-4.png', 'iphon14plus-267.iphon14plus-2.jpg', 15, '2022-10-30 01:16:02', '2022-10-30 05:11:49'),
(40, 'apple-117.apple-1.png', 'iphon14plus-35.iphon14plus-3.png', 15, '2022-10-30 01:16:02', '2022-10-30 05:11:55'),
(41, 'apple-28.apple-2.png', 'iphon14plus-498.iphon14plus-4.jpg', 15, '2022-10-30 01:16:02', '2022-10-30 05:12:00'),
(42, 'apple-369.apple-3.png', 'iphon14plus-515.iphon14plus-5.jpg', 15, '2022-10-30 01:16:02', '2022-10-30 05:12:05'),
(43, 'iphon14promax-180.iphon14promax-1.png', 'iphon14promax-180.iphon14promax-1.png', 22, '2022-10-30 05:18:26', '2022-10-30 05:18:26'),
(44, 'iphon14promax-276.iphon14promax-2.png', 'iphon14promax-276.iphon14promax-2.png', 22, '2022-10-30 05:18:26', '2022-10-30 05:18:26'),
(45, 'iphon14promax-391.iphon14promax-3.png', 'iphon14promax-391.iphon14promax-3.png', 22, '2022-10-30 05:18:26', '2022-10-30 05:18:26'),
(46, 'iphon14promax-432.iphon14promax-4.png', 'iphon14promax-432.iphon14promax-4.png', 22, '2022-10-30 05:18:26', '2022-10-30 05:18:26');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_10_17_083918_add_soft_delete_to_users', 2),
(8, '2022_10_19_030016_create_posts_category_table', 3),
(9, '2022_10_19_030406_create_posts_table', 4),
(10, '2022_10_21_145923_add_slug_to_posts_table', 5),
(11, '2022_10_22_034653_create_pages_table', 6),
(12, '2022_10_22_130542_create_category_products_table', 7),
(17, '2022_10_23_133930_create_gallerys_table', 9),
(20, '2022_10_25_124433_create_products_table', 10),
(21, '2022_10_26_150728_create_product_colors_table', 11),
(22, '2022_10_27_085725_add_product_status_to_products_table', 12),
(23, '2022_10_29_073103_add_properties_to_products_table', 13),
(24, '2022_11_01_032549_create_orders_table', 14),
(26, '2022_11_01_033407_create_orders_detail_table', 15),
(27, '2022_11_01_042057_add_color_to_users_table', 16),
(28, '2022_11_01_084937_add_price_total_to_orders_table', 17),
(29, '2022_11_01_093305_add_total_to_orders_detail_table', 18),
(31, '2022_11_02_023129_create_roles_table', 19),
(32, '2022_11_02_035112_create_role_user_table', 20),
(33, '2022_11_03_130702_create_sliders_table', 21);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price_total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`id`, `order_code`, `order_name`, `email`, `address`, `phone`, `notes`, `order_status`, `payment`, `created_at`, `updated_at`, `price_total`) VALUES
(22, 'UNIMART-4070', 'Cao Hải Đăng', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '2', '1', '2022-11-01 07:11:27', '2022-11-01 07:11:43', '355890000'),
(23, 'UNIMART-3126', 'Cao Gia Bảo', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '3', '1', '2022-11-01 07:12:47', '2022-11-03 02:26:10', '97470000'),
(24, 'UNIMART-7078', 'Cao Gia Bảo', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', 'Giao nhanh cho anh anh đang thừa tiền', '1', '1', '2022-11-01 07:29:05', '2022-11-01 07:35:48', '129960000'),
(25, 'UNIMART-4234', 'Cao Gia Bảo', 'admin@gmail.com', 'Thanh hóa', '0123456789', NULL, '0', '1', '2022-11-01 07:35:11', NULL, '83960000'),
(26, 'UNIMART-3058', 'Cao Hải Đăng', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '0', '1', '2022-11-03 18:34:32', NULL, '20990000'),
(27, 'UNIMART-3003', 'Cao Hải Đăng', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '0', '1', '2022-11-03 18:47:48', NULL, '32490000'),
(28, 'UNIMART-5722', 'Cao Hải Đăng', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '0', '1', '2022-11-03 18:50:12', NULL, '32490000'),
(34, 'UNIMART-9918', 'Cao Gia Bảo', 'bao19392633128@gmail.com', 'Thanh hóa', '0123456789', NULL, '2', '1', '2022-11-03 19:21:33', '2022-11-03 19:44:04', '102970000'),
(35, 'UNIMART-3960', 'Cao Thanh Vương', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '0', '1', '2022-11-03 19:24:49', NULL, '64980000'),
(36, 'UNIMART-4897', 'Test', 'dang48691216@gmail.com', 'Thanh hóa', '0123456789', NULL, '2', '1', '2022-11-03 19:29:02', '2022-11-03 19:45:32', '97470000'),
(37, 'UNIMART-139', 'Cao Gia Bảo Béo', 'bao19392633128@gmail.com', 'Thanh hóa', '0123456789', NULL, '2', '1', '2022-11-03 19:32:16', '2022-11-14 19:32:46', '117960000'),
(38, 'UNIMART-4440', 'Trần Thị Ngoan', 'ngoanthhp@gmail.com', 'Thanh hóa', '0123456789', NULL, '2', '1', '2022-11-05 08:51:40', '2022-11-14 19:32:57', '91470000'),
(39, 'UNIMART-6648', 'Cao Hải Đăng', 'dang48691216@gmail.com', 'Số nhà 05', '0123456789', NULL, '2', '1', '2022-11-14 01:47:03', '2022-11-14 19:32:57', '32490000'),
(40, 'UNIMART-3428', 'Test', 'bao19392633128@gmail.com', 'Thanh hóa', '0123456789', 'Giao sớm', '2', '1', '2022-11-14 01:48:36', '2022-11-14 19:32:57', '102970000'),
(41, 'UNIMART-7788', 'Cao Gia Bảo', 'bao19392633128@gmail.com', 'Số nhà 05', '0123456789', NULL, '2', '1', '2022-11-14 01:51:40', '2022-11-14 19:32:57', '32490000'),
(42, 'UNIMART-4543', 'Cao Gia Bảo', 'bao19392633128@gmail.com', 'Số nhà 05', '0123456789', NULL, '1', '1', '2022-11-14 01:51:55', '2022-11-14 19:33:06', '32490000'),
(43, 'UNIMART-5689', 'Cao Hải Đăng', 'bao19392633128@gmail.com', 'Thanh hóa', '0123456789', NULL, '1', '1', '2022-11-14 01:53:32', '2022-11-14 19:33:06', '32490000'),
(44, 'UNIMART-1757', 'Cao Hải Đăng', 'ngoanthhp@gmail.com', 'Thanh hóa', '0123456789', 'Giao sớm', '1', '1', '2022-11-14 01:55:53', '2022-11-14 19:33:06', '75980000'),
(45, 'UNIMART-6107', 'Cao Hải Đăng', 'ngoanthhp@gmail.com', 'Thanh hóa', '0123456789', 'Giao Sớm', '0', '1', '2022-11-14 01:58:10', NULL, '41980000'),
(46, 'UNIMART-2157', 'Cao Gia Bảo', 'bao19392633128@gmail.com', 'Thanh hóa', '0123456789', 'đang nhiều tiền giao nhanh', '0', '1', '2022-11-15 08:40:12', NULL, '74470000');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders_detail`
--

CREATE TABLE `orders_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qty` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `orders_detail`
--

INSERT INTO `orders_detail` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_qty`, `created_at`, `updated_at`, `color`, `thumbnail`, `total`) VALUES
(25, 22, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '5', '2022-11-01 07:11:27', '2022-11-01 07:11:27', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '162450000.00'),
(26, 22, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '3', '2022-11-01 07:11:27', '2022-11-01 07:11:27', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '113970000.00'),
(27, 22, 15, 'Điện thoại iPhone 14 Plus 128GB', '26490000', '3', '2022-11-01 07:11:27', '2022-11-01 07:11:27', 'Đen', 'public/uploads/product/iPhone-14-plus-thumb-den-600x600.jpg', '79470000.00'),
(28, 23, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '3', '2022-11-01 07:12:47', '2022-11-01 07:12:47', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '97470000.00'),
(29, 24, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '4', '2022-11-01 07:29:05', '2022-11-01 07:29:05', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '129960000.00'),
(30, 25, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '4', '2022-11-01 07:35:11', '2022-11-01 07:35:11', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '83960000.00'),
(31, 26, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '1', '2022-11-03 18:34:32', '2022-11-03 18:34:32', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '20990000.00'),
(32, 27, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-03 18:47:48', '2022-11-03 18:47:48', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(33, 28, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-03 18:50:12', '2022-11-03 18:50:12', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(34, 34, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '2', '2022-11-03 19:21:33', '2022-11-03 19:21:33', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '64980000.00'),
(35, 34, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '1', '2022-11-03 19:21:33', '2022-11-03 19:21:33', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '37990000.00'),
(36, 35, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '2', '2022-11-03 19:24:49', '2022-11-03 19:24:49', 'Đen', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '64980000.00'),
(37, 36, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '3', '2022-11-03 19:29:02', '2022-11-03 19:29:02', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '97470000.00'),
(38, 37, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-03 19:32:16', '2022-11-03 19:32:16', 'Tím', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(39, 37, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '1', '2022-11-03 19:32:16', '2022-11-03 19:32:16', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '37990000.00'),
(40, 37, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '1', '2022-11-03 19:32:16', '2022-11-03 19:32:16', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '20990000.00'),
(41, 37, 15, 'Điện thoại iPhone 14 Plus 128GB', '26490000', '1', '2022-11-03 19:32:16', '2022-11-03 19:32:16', 'Đỏ', 'public/uploads/product/iPhone-14-plus-thumb-den-600x600.jpg', '26490000.00'),
(42, 38, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '1', '2022-11-05 08:51:40', '2022-11-05 08:51:40', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '37990000.00'),
(43, 38, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-05 08:51:40', '2022-11-05 08:51:40', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(44, 38, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '1', '2022-11-05 08:51:40', '2022-11-05 08:51:40', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '20990000.00'),
(45, 39, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-14 01:47:03', '2022-11-14 01:47:03', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(46, 40, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '2', '2022-11-14 01:48:36', '2022-11-14 01:48:36', 'Đen', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '64980000.00'),
(47, 40, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '1', '2022-11-14 01:48:36', '2022-11-14 01:48:36', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '37990000.00'),
(48, 41, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-14 01:51:40', '2022-11-14 01:51:40', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(49, 42, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-14 01:51:55', '2022-11-14 01:51:55', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(50, 43, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-14 01:53:32', '2022-11-14 01:53:32', 'Đen', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(51, 44, 18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', '2', '2022-11-14 01:55:53', '2022-11-14 01:55:53', 'Đen', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '75980000.00'),
(52, 45, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '2', '2022-11-14 01:58:10', '2022-11-14 01:58:10', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '41980000.00'),
(53, 46, 22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', '1', '2022-11-15 08:40:12', '2022-11-15 08:40:12', 'Vàng Gold', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '32490000.00'),
(54, 46, 17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', '2', '2022-11-15 08:40:12', '2022-11-15 08:40:12', 'tím', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '41980000.00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name_page` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pages`
--

INSERT INTO `pages` (`id`, `name_page`, `slug`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Giới thiệu', 'Giới-thiệu', '<h1>Lorem Ipsum</h1>\r\n<p>&nbsp;</p>\r\n<div>\r\n<h2>What is Lorem Ipsum?</h2>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div>\r\n<h2>Where does it come from?</h2>\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n</div>\r\n<div>\r\n<h2>Where can I get some?</h2>\r\n<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n</div>', '2022-10-22 01:10:36', '2022-11-15 20:44:32'),
(5, 'Sản Phẩm', 'san-pham', '<p>Ch&iacute;nh s&aacute;ch đổi trả</p>', '2022-10-22 02:21:31', '2022-11-15 19:28:56'),
(6, 'Tin tức', 'tin-tuc', '<p>Blog</p>', '2022-11-15 19:27:31', '2022-11-15 19:43:23'),
(7, 'Liên hệ', 'lien-he', '<h1>Lorem Ipsum</h1>\r\n<div>\r\n<h2>What is Lorem Ipsum?</h2>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div>\r\n<h2>Where does it come from?</h2>\r\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n<h2>Where can I get some?</h2>\r\n<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n</div>', '2022-11-15 19:32:38', '2022-11-15 19:32:38'),
(8, 'Trang chủ', 'trang-chu', '<p>trang chủ</p>', '2022-11-15 19:33:53', '2022-11-15 19:39:10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_post_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `posts`
--

INSERT INTO `posts` (`id`, `thumbnail`, `title`, `content`, `category_post_id`, `created_at`, `updated_at`, `slug`) VALUES
(17, 'public/uploads/post/13_800x450-300x200.jpg', 'Kỳ vọng Xiaomi 14 Pro Concept: Thiết kế thời thượng, cấu hình mạnh với Snapdragon 8+ Gen 2', '<h3><strong>Xiaomi 14 Pro concept thời thượng v&agrave; đẹp mắt</strong></h3>\r\n<p>Kh&aacute; tiếc l&agrave; ở thời điểm viết b&agrave;i m&igrave;nh vẫn chưa t&igrave;m thấy h&igrave;nh ảnh r&ograve; rỉ, concept hay bản render n&agrave;o của Xiaomi 14 Pro. Ch&iacute;nh v&igrave; thế m&igrave;nh đ&atilde; sử dụng video concept của Xiaomi 13 Pro từ k&ecirc;nh YouTube HoiINDI v&agrave; kỳ vọng rằng khi Xiaomi 14 Pro n&agrave;y ra mắt cũng sẽ c&oacute; những đường n&eacute;t tương đồng.&nbsp;</p>\r\n<p>C&oacute; thể dễ d&agrave;ng nhận thấy thiết bị trong video concept c&oacute; thiết kế kh&aacute; quen thuộc so với những sản phẩm đến từ Xiaomi, đặc biệt l&agrave; ở cụm camera sau. B&ecirc;n cạnh đ&oacute;, m&aacute;y cũng sở hữu thiết kế phẳng v&agrave; vu&ocirc;ng vức hiện đang rất trend trong thời gian gần đ&acirc;y v&agrave; vẫn đang chưa c&oacute; dấu hiệu hạ nhiệt v&agrave; việc xuất hiện tr&ecirc;n nhiều thiết bị kh&aacute;c nhau từ ph&acirc;n kh&uacute;c cao cấp đến gi&aacute; rẻ.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/6_1280x720-800-resize.jpg\" alt=\"\" width=\"800\" height=\"450\" /></p>\r\n<p style=\"text-align: justify;\"><em>&nbsp;M&aacute;y cũng sở hữu thiết kế phẳng v&agrave; vu&ocirc;ng vức hiện đang rất trend .Nguồn: HoiINDI.</em></p>\r\n<p style=\"text-align: justify;\">Ch&iacute;nh v&igrave; thế m&igrave;nh mong rằng Xiaomi 14 Pro sẽ mang nhiều đường n&eacute;t thiết kế tương đồng với bản concept. B&ecirc;n cạnh đ&oacute;, m&igrave;nh cũng hy vọng rằng Xiaomi c&oacute; thể thay đổi c&aacute;ch thiết kế cụm camera để Xiaomi 14 Pro tr&ocirc;ng kh&aacute;c biệt hơn v&igrave; thời điểm m&aacute;y ra mắt c&ograve;n kh&aacute; l&acirc;u n&ecirc;n việc giữ phong c&aacute;ch thiết kế ở thời điểm hiện tại l&agrave; một điều kh&aacute; kh&oacute;.&nbsp;</p>\r\n<h3><strong>Xiaomi 14 Pro cấu h&igrave;nh mạnh mẽ với Snapdragon 8+ Gen 2</strong></h3>\r\n<p>Theo nhiều th&ocirc;ng tin nghe đồn th&igrave; Xiaomi 14 Pro sẽ được trang bị con chip Snapdragon 8 Gen 1 nhưng với c&aacute;c nh&acirc;n m&igrave;nh th&igrave; điều n&agrave;y l&agrave; chưa hợp l&yacute;. Đầu ti&ecirc;n l&agrave; v&igrave; hiện con chip di động cao cấp nhất đang l&agrave; Snapdragon 8+ Gen 1 với những cải tiến gi&uacute;p giảm thiểu hiện tượng qu&aacute; nhiệt v&agrave; hao pin. Hơn thế nữa, Xiaomi 13 Pro đang được đồn đo&aacute;n rằng sẽ sử dụng chip Snapdragon 8 Gen 2 v&agrave; Xiaomi 12 Pro trước đ&acirc;y cũng đ&atilde; d&ugrave;ng chip Snapdragon 8 Gen 1 rồi.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/5_1280x720-800-resize.jpg\" alt=\"\" width=\"800\" height=\"450\" /></p>\r\n<p><em>Th&ocirc;ng tin Xiaomi 14 Pro sẽ được trang bị con chip Snapdragon 8 Gen 1 được m&igrave;nh đ&aacute;nh gi&aacute; l&agrave; chưa hợp l&yacute; .Nguồn: HoiINDI.</em></p>\r\n<p>Ch&iacute;nh v&igrave; thế th&ocirc;ng tin Xiaomi 14 Pro sử dụng chip Snapdragon 8 Gen 1 hay thậm ch&iacute; l&agrave; 8+ Gen 1 cũng đều kh&ocirc;ng được m&igrave;nh tin tưởng cho lắm. Thay v&agrave;o đ&oacute;, m&igrave;nh kỳ vọng rằng Xiaomi 14 Pro sẽ sở hữu vi xử l&yacute; Snapdragon 8+ Gen 2. Với việc Qualcomm sắp giới thiệu Snapdragon 8 Gen 2 v&agrave; Xiaomi 13 Pro cũng sẽ sở hữu con chip n&agrave;y th&igrave; đ&acirc;y l&agrave; một kỳ vọng m&agrave; m&igrave;nh cho rằng kh&aacute; hợp l&yacute;.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/3_1280x720-800-resize.jpg\" alt=\"\" width=\"800\" height=\"450\" /></p>\r\n<p><em>Kỳ vọng rằng Xiaomi 14 Pro sẽ sở hữu vi xử l&yacute; Snapdragon 8+ Gen 2</em></p>\r\n<p>B&ecirc;n cạnh đ&oacute;, m&igrave;nh cũng mong rằng Xiaomi 14 Pro sẽ được trang bị RAM 12 GB c&ugrave;ng bộ nhớ trong tối thiểu 256 GB, c&oacute; thể mở rộng bằng thẻ microSD c&ugrave;ng t&iacute;nh năng RAM ảo c&oacute; thể chuyển đổi th&ecirc;m 4 GB. D&ugrave; nghe kh&aacute; cao ở thời điểm hiện tại nhưng bạn n&ecirc;n nhớ rằng thời gian ra mắt của Xiaomi 14 Pro l&agrave; c&ograve;n kh&aacute; l&acirc;u v&agrave; cuộc đua cấu h&igrave;nh tr&ecirc;n smartphone lại đang diễn ra rất gay gắt, ch&iacute;nh v&igrave; thế m&igrave;nh nghĩ th&ocirc;ng số như tr&ecirc;n l&agrave; hợp l&yacute; ở thời điểm m&aacute;y tr&igrave;nh l&agrave;ng.</p>\r\n<p><strong>Theo những kỳ vọng của bản th&acirc;n, th&ocirc;ng số cấu h&igrave;nh Xiaomi 14 Pro cụ thể&nbsp;</strong><strong>như sau:</strong></p>\r\n<p>&nbsp;</p>\r\n<ul>\r\n<li>M&agrave;n h&igrave;nh: K&iacute;ch thước 6.7 inch, độ ph&acirc;n giải 2K, tấm nền AMOLED, tần số qu&eacute;t 144 Hz.</li>\r\n<li>CPU: Snapdragon 8+ Gen 2.</li>\r\n<li>RAM: 12 GB.</li>\r\n<li>Bộ nhớ trong: 256 GB, 512 GB v&agrave; 1 TB.</li>\r\n<li>Camera sau: 108 MP + 50 MP + 50 MP.</li>\r\n<li>Camera trước: 32 MP.</li>\r\n<li>Pin: 5.500 mAh.</li>\r\n</ul>\r\n<h3><strong>Xiaomi 14 Pro m&agrave;n h&igrave;nh 2K c&ugrave;ng pin 5.500 mAh</strong></h3>\r\n<p>Về m&agrave;n h&igrave;nh th&igrave; m&igrave;nh kỳ vọng rằng Xiaomi 14 Pro sẽ sở hữu tấm nền LTPO AMOLED k&iacute;ch thước 6.7 inch độ ph&acirc;n giải 2K, tần số qu&eacute;t 144 Hz. Với những th&ocirc;ng số n&agrave;y, Xiaomi 14 Pro hứa hẹn sẽ mang đến trải nghiệm giải tr&iacute; rất ấn tượng, d&ugrave; kh&ocirc;ng c&oacute; sự n&acirc;ng cấp về độ ph&acirc;n giải nhưng m&igrave;nh đ&aacute;nh gi&aacute; l&agrave; bấy nhi&ecirc;u đ&atilde; đủ để cho ra độ chi tiết ấn tượng rồi. Nếu tăng độ ph&acirc;n giải l&ecirc;n cao hơn chỉ l&atilde;ng ph&iacute; t&agrave;i nguy&ecirc;n v&agrave; hao pin nhiều hơn m&agrave; th&ocirc;i.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/2_1280x720-800-resize.jpg\" alt=\"\" width=\"800\" height=\"450\" /></p>\r\n<p><em>Xiaomi 14 Pro sẽ sở hữu tấm nền LTPO AMOLED k&iacute;ch thước 6.7 inch độ ph&acirc;n giải 2K, tần số qu&eacute;t 144 Hz .Nguồn: HoiINDI.</em></p>\r\n<p>Thay v&igrave; l&atilde;ng ph&iacute; v&agrave;o cuộc đua độ ph&acirc;n giải th&igrave; h&atilde;ng c&oacute; thể tập chung chi ph&iacute; để ph&aacute;t triển th&ecirc;m c&aacute;c t&iacute;nh năng kh&aacute;c như c&ocirc;ng nghệ camera dưới m&agrave;n h&igrave;nh chẳng hạn. Đ&acirc;y sẽ l&agrave; một cải tiến đ&aacute;ng gi&aacute; v&agrave; hợp l&yacute; hơn nhiều.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/4_1280x720-800-resize.jpg\" /></p>\r\n<p><em>Thay v&agrave;o đ&oacute; th&igrave; m&igrave;nh mong h&atilde;ng c&oacute; thể tập trung chi ph&iacute; để ph&aacute;t triển th&ecirc;m c&aacute;c t&iacute;nh năng kh&aacute;c như c&ocirc;ng nghệ camera dưới m&agrave;n h&igrave;nh chẳng hạn .Nguồn: HoiINDI.</em></p>\r\n<p>B&ecirc;n cạnh đ&oacute;, m&igrave;nh cũng kỳ vọng rằng Xiaomi 14 Pro sẽ được trang bị vi&ecirc;n pin dung lượng 5.500 mAh. Nguy&ecirc;n nh&acirc;n l&agrave; v&igrave; ở thời điểm hiện tại, mức pin 5.000 mAh đang rất phổ biến, gi&uacute;p c&acirc;n bằng tốt giữa thời lượng v&agrave; thiết kế của m&aacute;y. Tuy nhi&ecirc;n, với sự ph&aacute;t triển ng&agrave;y c&agrave;ng mạnh mẽ của c&ocirc;ng nghệ th&igrave; m&igrave;nh kỳ vọng rằng c&aacute;c nh&agrave; sản xuất sẽ c&oacute; c&aacute;c giải ph&aacute;p để tối ưu k&iacute;ch thước của những vi&ecirc;n pin, gi&uacute;p m&aacute;y c&oacute; th&ecirc;m thời lượng sử dụng nhưng vẫn kh&ocirc;ng ảnh hưởng đến thiết kế.&nbsp;</p>\r\n<h3><strong>Xiaomi 14 Pro camera ch&iacute;nh 108 MP cho chất lượng ảnh sắc n&eacute;t</strong></h3>\r\n<p>M&igrave;nh kỳ vọng Xiaomi 14 Pro sẽ được trang bị cụm camera với th&ocirc;ng số như sau:</p>\r\n<ul>\r\n<li>Camera ch&iacute;nh: Độ ph&acirc;n giải 108 MP.</li>\r\n<li>Camera g&oacute;c si&ecirc;u rộng: Độ ph&acirc;n giải 50 MP.</li>\r\n<li>Camera tele: Độ ph&acirc;n giải 50 MP.</li>\r\n<li>Camera trước 32 MP.</li>\r\n</ul>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/9_1280x720-800-resize.jpg\" /></p>\r\n<p><em>Xiaomi 14 Pro camera ch&iacute;nh 108 MP cho chất lượng ảnh sắc n&eacute;t .Nguồn: HoiINDI.</em></p>\r\n<p>Với hệ thống camera n&agrave;y, Xiaomi 14 Pro hứa hẹn sẽ mang đến những bức ảnh với độ chi tiết cao, sắc n&eacute;t v&agrave; đẹp mắt. Hơn thế nữa m&igrave;nh mong rằng Xiaomi 14 Pro sẽ được ph&aacute;t triển th&ecirc;m c&aacute;c t&iacute;nh năng AI như c&aacute;ch m&agrave; Google đang l&agrave;m với những chiếc điện thoại của h&atilde;ng để mang đến cho người d&ugrave;ng khả năng xử l&yacute; h&igrave;nh ảnh ấn tượng.&nbsp;</p>\r\n<h3><strong>Xiaomi 14 Pro gi&aacute; bao nhi&ecirc;u? Khi n&agrave;o Xiaomi 14 Pro ra mắt?</strong></h3>\r\n<p>Thời gian ra mắt của Xiaomi 14 Pro được m&igrave;nh kỳ vọng sẽ tương đồng với những sản phẩm tiền nhiệm, cụ thể l&agrave; v&agrave;o khoảng th&aacute;ng 11/2023 (Xiaomi 13 Pro được cho l&agrave; sẽ tr&igrave;nh l&agrave;ng v&agrave;o th&aacute;ng 11/2022). C&ograve;n về gi&aacute; b&aacute;n th&igrave; m&igrave;nh mong Xiaomi 14 Pro sẽ c&oacute; gi&aacute; từ 28 triệu đồng.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/08/1485063/1_1280x720-800-resize.jpg\" /></p>\r\n<p>Tr&ecirc;n đ&acirc;y l&agrave; những kỳ vọng của m&igrave;nh về Xiaomi 14 Pro. Vậy c&ograve;n bạn, bạn c&oacute; những &yacute; kiến g&igrave; kh&aacute;c về sản phẩm n&agrave;y hay kh&ocirc;ng? H&atilde;y để lại b&igrave;nh luận ngay b&ecirc;n dưới cho ch&uacute;ng m&igrave;nh được biết nh&eacute;! Rất cảm ơn c&aacute;c bạn đ&atilde; đọc hết b&agrave;i viết của m&igrave;nh.&nbsp;</p>', 18, '2022-10-21 07:51:26', '2022-11-17 06:26:02', 'ky-vong-xiaomi-14-pro-concept-thiet-ke-thoi-thuong-cau-hinh-manh-voi-snapdragon-8-gen-2'),
(18, 'public/uploads/post/chuyen-ho-so-netflix-04_800x450-300x200.jpg', 'Cách chuyển hồ sơ Netflix giúp di chuyển thông tin sang tài khoản mới cực kỳ nhanh', '<h3><strong>C&aacute;ch chuyển hồ sơ Netflix</strong></h3>\r\n<p>Để chuyển được hồ sơ Netflix th&igrave; c&aacute;c bạn h&atilde;y lưu &yacute; v&agrave; l&agrave;m theo c&aacute;c bước dưới đ&acirc;y nha.</p>\r\n<p><strong>Bước 1:&nbsp;</strong>Đầu ti&ecirc;n c&aacute;c bạn truy cập v&agrave;o&nbsp;<strong>Netflix</strong>&nbsp;c&oacute; chứa hồ sơ m&agrave; bạn cần chuyển &gt; Sau đ&oacute; đưa chuột lại t&agrave;i khoản của bạn k&iacute;ch chọn&nbsp;<strong>Chuyển hồ sơ.</strong></p>\r\n<p><strong><img src=\"https://cdn.tgdd.vn/Files/2022/10/23/1480991/chuyen-ho-so-netflix-01_1280x720-800-resize.jpg\" /></strong></p>\r\n<p><strong>Bước 2:&nbsp;</strong>Tại đ&acirc;y bạn k&iacute;ch chọn v&agrave;o<strong>&nbsp;Cho ph&eacute;p</strong>&nbsp;th&igrave; ngay lập tức Netflix sẽ gởi một li&ecirc;n kết về mail đ&atilde; đăng k&yacute; của bạn, bạn v&agrave;o mail k&iacute;ch chọn v&agrave; l&agrave;m theo hướng dẫn l&agrave; được th&ocirc;i nha.</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/10/23/1480991/chuyen-ho-so-netflix-02_1280x720-800-resize.jpg\" /></p>\r\n<p>Như vậy, m&igrave;nh đ&atilde; chia sẻ c&aacute;ch chuyển hồ sơ Netflix. Cảm ơn c&aacute;c bạn đ&atilde; d&agrave;nh &iacute;t thời gian để xem b&agrave;i viết của m&igrave;nh.</p>\r\n<p>&nbsp;</p>', 18, '2022-10-21 08:20:19', '2022-11-17 06:26:08', 'cach-chuyen-ho-so-netflix-giup-di-chuyen-thong-tin-sang-tai-khoan-moi-cuc-ky-nhanh'),
(19, 'public/uploads/post/thumb_1280x720-300x200.png', 'Tính năng tiên đoán các cử chỉ trên Android 14 sẽ được cải tiến đáng kể', '<h3><strong>T&iacute;nh năng ti&ecirc;n đo&aacute;n c&aacute;c cử chỉ tr&ecirc;n Android 14 sẽ được cải tiến đ&aacute;ng kể</strong></h3>\r\n<p>&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/15/1487245/h2_1280x720-800-resize.png\" /></p>\r\n<p><em>T&iacute;nh năng ti&ecirc;n đo&aacute;n c&aacute;c cử chỉ tr&ecirc;n Android 14 sẽ được cải tiến đ&aacute;ng kể (Ảnh: Google)</em></p>\r\n<p>Trước đ&acirc;y, Android 13 đ&atilde; c&oacute; t&iacute;nh năng ti&ecirc;n đo&aacute;n thao t&aacute;c quay về (predictive back) nhằm nhắc nhở người d&ugrave;ng mỗi khi tho&aacute;t ứng dụng hoặc quay về m&agrave;n h&igrave;nh ch&iacute;nh. Giờ đ&acirc;y, Android 14 sắp được ra mắt sẽ mang đến nhiều t&iacute;nh năng mới, trong đ&oacute; c&oacute; cả t&iacute;nh năng ti&ecirc;n đo&aacute;n cử chỉ được cải tiến v&agrave; chạy ngầm trong c&aacute;c ứng dụng để đưa ra dự đo&aacute;n tốt hơn cho người d&ugrave;ng.&nbsp;</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/15/1487245/giao-dien-tinh-nang-moi_1280x720-800-resize.png\" /></p>\r\n<p>&nbsp; <em>T&iacute;nh năng ti&ecirc;n đo&aacute;n thao t&aacute;c quay về (Ảnh: 9to5google)</em></p>\r\n<p>&nbsp;</p>\r\n<p>Cụ thể, t&iacute;nh năng n&agrave;y gi&uacute;p bạn hạn chế việc tho&aacute;t khỏi ứng dụng hoặc chuyển qua ứng dụng kh&aacute;c kh&ocirc;ng theo &yacute; muốn, đồng thời cũng cho bạn xem trước m&agrave;n h&igrave;nh m&agrave; bạn sắp chuyển cũng như ứng dụng đang chạy.</p>\r\n<p>Trong phần &ldquo;Thiết kế ứng dụng chất lượng cao với c&aacute;c t&iacute;nh năng mới nhất của Android&rdquo; (Designing a High Quality App with the Latest Android Features) tại lộ tr&igrave;nh theo d&otilde;i nền tảng của Hội nghị thượng đỉnh d&agrave;nh cho nh&agrave; ph&aacute;t triển Android năm 2022, Google đ&atilde; n&oacute;i về &ldquo;falsing&rdquo; - một thuật ngữ về việc thao t&aacute;c quay về đ&ocirc;i khi dẫn đến &ldquo;mọi người tho&aacute;t khỏi ứng dụng do v&ocirc; t&igrave;nh&rdquo;, do đ&oacute; ảnh hưởng đến trải nghiệm.</p>\r\n<p>Một số người d&ugrave;ng cho biết: &ldquo;T&ocirc;i kh&ocirc;ng thể thấy được m&agrave;n h&igrave;nh đang được sử dụng trước khi chuyển về m&agrave;n h&igrave;nh ch&iacute;nh&rdquo;. Google cho biết điều hướng bằng cử chỉ l&agrave; &ldquo;m&ocirc; h&igrave;nh tương t&aacute;c nhanh, tự nhi&ecirc;n v&agrave; thuận tiện&rdquo;.</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/15/1487245/quay-lai-tren-android-13_1280x1280-800-resize.png\" /></p>\r\n<p><em>Thao t&aacute;c quay về đ&atilde; từng c&oacute; tr&ecirc;n Android 13 (Ảnh: TheVerge)</em></p>\r\n<p>&nbsp;</p>\r\n<p>Việc ti&ecirc;n đo&aacute;n cử chỉ quay về (predictive back) l&agrave; giải ph&aacute;p của Google để gi&uacute;p người d&ugrave;ng thu nhỏ lại m&agrave;n h&igrave;nh ứng dụng (đang sử dụng) trước khi chuyển về giao diện m&agrave;n h&igrave;nh ch&iacute;nh. T&iacute;nh năng n&agrave;y đang được thử nghiệm tr&ecirc;n Google Phone v&agrave; TV bằng c&aacute;ch bật \"T&ugrave;y chọn d&agrave;nh nh&agrave; ph&aacute;t triển\".</p>\r\n<p>Android 14 sẽ bật ti&ecirc;n đo&aacute;n cử chỉ quay về theo mặc định, trong khi Android 14 sắp tới được thiết lập để cung cấp &ldquo;trải nghiệm tương tự khi người d&ugrave;ng vuốt trong ứng dụng. Cho ph&eacute;p người d&ugrave;ng biết nơi sẽ đưa họ trở lại bằng c&aacute;ch tận dụng hoạt ảnh mặc định hoặc t&ugrave;y chỉnh.&rdquo;</p>\r\n<p>V&iacute; dụ đầu ti&ecirc;n của thay đổi l&agrave; mở sự kiện trong Lịch Google v&agrave; sau đ&oacute; từ từ vuốt trở về. Trong l&uacute;c vuốt, trang sự kiện to&agrave;n m&agrave;n h&igrave;nh sẽ co lại cho đến khi bạn bắt đầu nh&igrave;n thấy m&agrave;n h&igrave;nh trước đ&oacute; (chế độ xem danh s&aacute;ch Lịch biểu). Sau đ&oacute; được kết hợp với một hoạt ảnh từ Lịch Google để hiển thị thẻ sự kiện trong danh s&aacute;ch.</p>\r\n<p><img src=\"https://cdn.tgdd.vn/Files/2022/11/15/1487245/android-13-predictable-backtgdd_1280x720-800-resize.jpg\" /></p>\r\n<p><em>T&iacute;nh năng ti&ecirc;n đo&aacute;n thao t&aacute;c quay về được giới thiệu tại Google I/O 2022 (Ảnh: Google)</em></p>\r\n<p>&nbsp;</p>\r\n<p>Để so s&aacute;nh r&otilde; hơn, thao t&aacute;c vuốt từ cạnh tr&aacute;i tr&ecirc;n iOS sẽ hiển thị m&agrave;n h&igrave;nh trước đ&oacute; của bạn th&ocirc;ng qua ph&eacute;p ẩn dụ khung trượt lần đầu ti&ecirc;n hiển thị ph&iacute;a b&ecirc;n tr&aacute;i của m&agrave;n h&igrave;nh trước đ&oacute;. C&ograve;n Android sẽ thu nhỏ chế độ xem hiện tại như một phần của t&ugrave;y chọn d&agrave;nh cho thẻ.</p>\r\n<p>Đ&acirc;y l&agrave; t&iacute;nh năng sắp được ra mắt trong Android 14, v&agrave; sẽ được Google đưa v&agrave;o bản beta v&agrave;o đầu năm tới. Thật l&agrave; đ&aacute;ng để mong chờ phải kh&ocirc;ng n&agrave;o?</p>', 18, '2022-11-03 06:38:33', '2022-11-17 06:26:14', 'tinh-nang-tien-doan-cac-cu-chi-tren-android-14-se-duoc-cai-tien-dang-ke'),
(20, 'public/uploads/post/lien-lac-ve-tinh-iPhone-14-2-696x364.jpg', 'Đây là cách tính năng liên lạc qua vệ tinh trên iPhone 14 hoạt động', '<p>D&ograve;ng iPhone 14 c&oacute; 1 t&iacute;nh năng ho&agrave;n to&agrave;n mới gọi l&agrave; Emergency SOS via Satellite Mode. Đ&acirc;y l&agrave; t&iacute;nh năng li&ecirc;n lạc qua vệ tinh ho&agrave;n to&agrave;n mới được Apple ph&aacute;t triển v&agrave; sắp c&oacute; mặt tại Mỹ c&ugrave;ng Canada.</p>\r\n<h2><strong>T&iacute;nh năng li&ecirc;n lạc qua vệ tinh tr&ecirc;n iPhone 14</strong></h2>\r\n<p>Theo th&ocirc;ng tin giới thiệu của Apple &ldquo;Khi người d&ugrave;ng iPhone gửi tin nhắn SOS khẩn cấp, n&oacute; sẽ di chuyển với tốc độ khoảng 25.749 km/h v&agrave; được nhận bởi một trong 24 vệ tinh quỹ đạo Tr&aacute;i đất thấp của Globalstar. Th&ocirc;ng điệp sau đ&oacute; tiếp tục được truyền qua vệ tinh đến c&aacute;c trạm mặt đất đặt tại c&aacute;c điểm tr&ecirc;n khắp thế giới.&rdquo;</p>\r\n<p><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/lien-lac-ve-tinh-iPhone-14-1-696x394.jpg\" /></p>\r\n<p>Cobham Satcom ở Concord, California đ&atilde; thiết kế v&agrave; chế tạo c&aacute;c ăng-ten c&ocirc;ng suất cao mới d&agrave;nh ri&ecirc;ng cho Apple. Mỗi trạm mặt đất sẽ c&oacute; nhiều ăng-ten để li&ecirc;n lạc với c&aacute;c vệ tinh. Khi trạm mặt đất nhận được tin nhắn, tin nhắn sẽ được chuyển tiếp đến c&aacute;c dịch vụ khẩn cấp hoặc trung t&acirc;m chuyển tiếp do c&aacute;c chuy&ecirc;n gia của Apple đảm nhiệm.</p>\r\n<p>Apple đ&atilde; trả rất nhiều tiền cho những n&acirc;ng cấp quan trọng đối với mạng vệ tinh v&agrave; trạm mặt đất của Globalstar. Do đ&oacute;, hơn 300 nh&acirc;n vi&ecirc;n Globalstar sẽ hỗ trợ dịch vụ Emergency SOS mới cho d&ograve;ng iPhone 14. Apple&nbsp;cho biết th&ecirc;m&nbsp;rằng t&iacute;nh năng gửi li&ecirc;n lạc qua vệ tinh sẽ sử dụng băng tần d&agrave;nh ri&ecirc;ng cho c&aacute;c vệ tinh di động.</p>\r\n<p><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/lien-lac-ve-tinh-iPhone-14-3-696x409.jpg\" /></p>\r\n<p>Hiện tại, t&iacute;nh năng n&agrave;y chỉ giới hạn ở Mỹ v&agrave; Canada. C&oacute; vẻ như Apple cũng kh&ocirc;ng c&oacute; kế hoặc mở rộng ra b&ecirc;n ngo&agrave;i trong thời gian tới.</p>', 19, '2022-11-15 07:56:29', '2022-11-17 06:26:39', 'day-la-cach-tinh-nang-lien-lac-qua-ve-tinh-tren-iphone-14-hoat-dong'),
(21, 'public/uploads/post/Review-Lenovo-YOGA-Slim-7-Carbon-5.png', 'Review Lenovo YOGA Slim 7 Carbon: Gần đến mức hoàn hảo', '<p>Lenovo YOGA Slim l&agrave; một trong những Series&nbsp;<strong>Laptop Lenovo</strong>&nbsp;si&ecirc;u mỏng nhẹ với khả năng xoay gập đa năng; đi c&ugrave;ng ngoại h&igrave;nh cực sang trọng v&agrave; được t&iacute;ch hợp một cấu h&igrave;nh mạnh mẽ, d&agrave;nh cho c&aacute;c t&aacute;c vụ đa nhiệm</p>\r\n<p><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-5.png\" /></p>\r\n<p>Đến với<strong>&nbsp;Lenovo YOGA Slim 7 Carbon&nbsp;</strong>&ndash; chiếc Laptop n&agrave;y tự h&agrave;o c&oacute; một CPU mạnh mẽ v&agrave; m&agrave;n h&igrave;nh OLED tuyệt đẹp với kiểu d&aacute;ng nhẹ, kiểu d&aacute;ng đẹp, cao cấp; đi c&ugrave;ng sự kết hợp của bộ vi xử l&yacute; mạnh mẽ đến từ nh&agrave; AMD. V&agrave; Lenovo đ&atilde; tuy&ecirc;n bố đ&acirc;y l&agrave; m&aacute;y t&iacute;nh x&aacute;ch tay OLED 14 inch nhẹ nhất thế giới. Vậy điều n&agrave;y c&oacute; ch&iacute;nh x&aacute;c? C&ugrave;ng m&igrave;nh đi chứng thực điều đ&oacute; nh&eacute;.</p>\r\n<h2><strong>Sự kết hợp của AMD</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-4.png\" /></strong></p>\r\n<p>Nếu l&agrave; fan của Series Lenovo YOGA Slim, bạn chắc chắn sẽ biết về <strong>Lenovo Yoga Slim 7i Carbon</strong> &ndash; Một Series Laptop đ&atilde; d&agrave;nh được Giải thưởng C&ocirc;ng nghệ ở hạng mục M&aacute;y t&iacute;nh x&aacute;ch tay si&ecirc;u di động tốt nhất được b&igrave;nh chọn bởi Hardwarezone trong năm 2021.&nbsp;</p>\r\n<p>V&agrave; tiếp nối sự th&agrave;nh c&ocirc;ng đ&oacute;, ch&iacute;nh l&agrave; Lenovo YOGA Slim 7 Carbon &ndash; bạn sẽ nhận ra rằng n&oacute; kh&ocirc;ng c&oacute; chữ &ldquo;i&rdquo; sau số &ldquo;7&rdquo;, một sự ra đời tiếp nối th&agrave;nh c&ocirc;ng của Lenovo Yoga Slim 7i Carbon. YOGA Slim 7 Carbon được trang bị bộ vi xử l&yacute; l&ecirc;n đến AMD Ryzen 7 5800U v&agrave; m&agrave;n h&igrave;nh OLED đem đến chất lượng h&igrave;nh ảnh ch&acirc;n thực nhất, v&agrave; tất cả được g&oacute;i gọn trong một chiếc Laptop si&ecirc;u mỏng nhẹ.</p>\r\n<h2><strong>Th&ocirc;ng số kỹ thuật v&agrave; Thiết kế</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-3.png\" /></strong></p>\r\n<p>Khi&nbsp;<strong>review Lenovo YOGA Slim 7 Carbon</strong>, m&igrave;nh dễ d&agrave;ng nhận ra sự thay đổi lớn nhất của&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>l&agrave; n&oacute; được trang bị bộ vi xử l&yacute; d&ograve;ng Ryzen 5000 của AMD. Những bộ vi xử l&yacute; n&agrave;y đ&atilde; được c&ocirc;ng bố v&agrave;o đầu năm 2021, tại CES 2021, nhưng b&acirc;y giờ những bộ vi xử l&yacute; n&agrave;y mới xuất hiện tr&ecirc;n nhiều mẫu Laptop trang bị chip AMD.&nbsp;&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>sẽ c&oacute; 4 biến thể để người d&ugrave;ng lựa chọn</p>\r\n<table style=\"border-collapse: collapse; background-color: #2dc26b; border-color: #F1C40F; border-style: solid;\" border=\"1px\" cellspacing=\"10px\" cellpadding=\"5px\">\r\n<tbody>\r\n<tr style=\"height: 22.3906px;\">\r\n<td style=\"width: 7.65097%; height: 22.3906px;\"><strong>M&agrave;n h&igrave;nh</strong></td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">OLED 14 inch, độ ph&acirc;n giải 2,8K</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">OLED 14 inch, độ ph&acirc;n giải 2,8K</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">OLED 14 inch, độ ph&acirc;n giải 2,8K</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">OLED 14 inch, độ ph&acirc;n giải 2,8K</td>\r\n</tr>\r\n<tr style=\"height: 44.7812px;\">\r\n<td style=\"width: 7.65097%; height: 44.7812px;\"><strong>Bộ vi xử l&yacute;</strong></td>\r\n<td style=\"width: 21.7451%; height: 44.7812px;\">AMD Ryzen 5 5600U</td>\r\n<td style=\"width: 21.7451%; height: 44.7812px;\">AMD Ryzen 5 5600U</td>\r\n<td style=\"width: 21.7451%; height: 44.7812px;\">AMD Ryzen 7 5800U</td>\r\n<td style=\"width: 21.7451%; height: 44.7812px;\">AMD Ryzen 7 5800U</td>\r\n</tr>\r\n<tr style=\"height: 22.3906px;\">\r\n<td style=\"width: 7.65097%; height: 22.3906px;\"><strong>RAM</strong></td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">16GB</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">16GB</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">16GB</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">16GB</td>\r\n</tr>\r\n<tr style=\"height: 22.3906px;\">\r\n<td style=\"width: 7.65097%; height: 22.3906px;\"><strong>Bộ nhớ</strong></td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">SSD 512GB M.2 PCIe</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">SSD 512GB M.2 PCIe</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">SSD 512GB M.2 PCIe</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">SSD 512GB M.2 PCIe</td>\r\n</tr>\r\n<tr style=\"height: 22.3906px;\">\r\n<td style=\"width: 7.65097%; height: 22.3906px;\"><strong>Đồ họa</strong></td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">Radeon Vega 7</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">NVIDIA GeForce MX450</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">Radeon Vega 8</td>\r\n<td style=\"width: 21.7451%; height: 22.3906px;\">NVIDIA GeForce MX450</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Nếu xem x&eacute;t qua c&aacute;c th&ocirc;ng số kỹ thuật,&nbsp;<strong>Yoga Slim 7 Carbon&nbsp;</strong>c&oacute; những mức gi&aacute; kh&aacute; hấp dẫn tr&ecirc;n Ho&agrave;ng H&agrave; Mobile. Bất kể cấu h&igrave;nh m&aacute;y bạn chọn l&agrave; g&igrave;, bạn sẽ c&oacute; được m&agrave;n h&igrave;nh OLED với độ ph&acirc;n giải cao, RAM 16 GB v&agrave; SSD 512 GB.&nbsp;</p>\r\n<p>Thực sự th&igrave;&nbsp;<strong>Yoga Slim 7 Carbon</strong>&nbsp;kh&ocirc;ng phải l&agrave; chiếc Laptop đẹp nhất. N&oacute; chỉ c&oacute; sự lựa chọn cho m&agrave;u x&aacute;m đen v&agrave; x&aacute;m xi măng, m&agrave; kh&ocirc;ng c&oacute; nhiều sự lựa chọn m&agrave;u sắc như những chiếc Ultrabook kh&aacute;c.</p>\r\n<p><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-1.png\" /></p>\r\n<p>Leonovo đ&atilde; tuy&ecirc;n bố đ&acirc;y l&agrave; chiếc Laptop OLED 14inch nhẹ nhất thế giới, mặc d&ugrave; LG đ&atilde; đ&aacute;nh bại n&oacute;i bằng series LG Gram 2022 vừa được ra mắt. Nhưng,&nbsp;<strong>Yoga Slim 7 Carbon&nbsp;</strong>vẫn l&agrave; chiếc Laptop si&ecirc;u mỏng nhẹ với sức mạnh đ&aacute;ng gờm trong ph&acirc;n kh&uacute;c gi&aacute; của n&oacute;. Để đạt được trọng lượng si&ecirc;u nhẹ đ&oacute;,&nbsp;<strong>Yoga Slim 7 Carbon&nbsp;</strong>c&oacute; khung m&aacute;y được l&agrave;m từ hợp kim magie cao cấp, d&agrave;nh cho h&agrave;ng kh&ocirc;ng vũ trụ v&agrave; kết hợp sợi carbon; nhưng bạn đừng nh&igrave;n v&agrave;o thiết kế mỏng nhẹ của n&oacute; m&agrave; đ&aacute;nh gi&aacute; n&oacute; kh&ocirc;ng bền bỉ, Lenovo cho biết,&nbsp;<strong>Yoga Slim 7 Carbon&nbsp;</strong>đ&aacute;p ứng c&aacute;c ti&ecirc;u chuẩn MIL-STD-810H, v&agrave; đ&atilde; được kiểm chứng cho c&aacute;c t&igrave;nh huống rơi rớt, va đập, vận chuyển h&agrave;ng kh&ocirc;ng, c&aacute;c điều kiện nhiệt độ v&agrave; khả năng kh&aacute;ng nước chống bụi.&nbsp;</p>\r\n<p><strong>Yoga Slim 7 Carbon&nbsp;</strong>cũng giống với t&ecirc;n gọi của n&oacute; l&agrave; mỏng nhẹ v&agrave; khả năng xoay gập c&ugrave;ng bản lề c&oacute; khả năng gập mở 180 độ.</p>\r\n<h2><strong>Review Lenovo YOGA Slim 7 Carbon: Cổng kết nối</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-3.jpg\" /></strong></p>\r\n<p>Khi&nbsp;<strong>review Lenovo YOGA Slim 7 Carbon</strong>&nbsp;n&agrave;y, m&igrave;nh thực sự kh&ocirc;ng qu&aacute; ấn tượng về cổng kết nối của chiếc Laptop n&agrave;y. N&oacute; được trang bị 3 cổng USB-C 3.2 v&agrave; kh&ocirc;ng c&oacute; Thunderboldt n&agrave;o để bạn c&oacute; thể sử dụng cho việc sạc pin Laptop, cổng Jack 3.5mm cho tai nghe v&agrave; micro kết hợp, c&ocirc;ng tắc e-Shutter của webcam v&agrave; 1 n&uacute;t nguồn.&nbsp;<strong>YOGA Slim 7 Carbon&nbsp;</strong>kh&ocirc;ng hề được trang bị cổng USB-A th&ocirc;ng thường v&agrave; cũng kh&ocirc;ng c&oacute; cổng HDMI.&nbsp;Tuy nhi&ecirc;n đ&acirc;y cũng l&agrave; điều dễ hiểu khi YOGA Slim 7 Carbon l&agrave; một chiếc Laptop si&ecirc;u mỏng nhẹ, với cổng HDMI kh&ocirc;ng được trang bị, bạn sẽ được thay thế bằng một cổng USB-C 3.2 Thế hệ 2 (DisplayPort 1.4 + PD 3.0) tr&ecirc;n m&aacute;y.&nbsp;</p>\r\n<p>Một điểm an ủi th&ecirc;m ở đ&acirc;y ch&iacute;nh l&agrave; kết nối kh&ocirc;ng d&acirc;y của m&aacute;y vẫn tốt v&igrave; c&oacute; hỗ trợ Wi-Fi 6 (802.11ax) v&agrave; Bluetooth 5.1.</p>\r\n<h2><strong>M&agrave;n h&igrave;nh của Lenovo YOGA Slim 7 Carbon</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-1-2048x1152.jpg\" /></strong></p>\r\n<p>M&agrave;n h&igrave;nh hiển thị l&agrave; điểm nổi bật khi&nbsp;<strong>Review Lenovo YOGA Slim 7 Carbon,&nbsp;</strong>chiếc laptop được n&acirc;ng cấp v&agrave; trang bị tấm nền OLED với tỷ lệ khung h&igrave;nh 16:10, tần số qu&eacute;t 90Hz v&agrave; độ ph&acirc;n giải 2880 x 1800 pixel. M&agrave;n h&igrave;nh c&ograve;n c&oacute; độ bao phủ m&agrave;u l&ecirc;n đến 100%sRGB v&agrave; đ&atilde; được Pantone x&aacute;c nhận, đ&acirc;y chắc chắn sẽ l&agrave; một chiếc Laptop c&oacute; m&agrave;n h&igrave;nh l&yacute; tưởng d&agrave;nh cho c&aacute;c bạn Content Creator hay l&agrave;m việc với c&aacute;c m&agrave;u sắc.</p>\r\n<p>N&oacute; cũng đ&aacute;p ứng c&aacute;c th&ocirc;ng số kỹ thuật DisplayHDR 500 True Black của VESA v&agrave; c&oacute; độ s&aacute;ng cao nhất l&agrave; 600 nits, tức l&agrave; cho d&ugrave; bạn c&oacute; l&agrave;m việc với m&agrave;n h&igrave;nh dưới &aacute;nh s&aacute;ng mặt trời trực tiếp, th&igrave; bạn vẫn c&oacute; thể nh&igrave;n thấy được m&agrave;n h&igrave;nh một c&aacute;ch r&otilde; n&eacute;t; c&oacute; thể n&oacute;i đ&acirc;y l&agrave; một th&ocirc;ng số tuyệt vời d&agrave;nh cho một chiếc m&agrave;n h&igrave;nh laptop.&nbsp;Tuy nhi&ecirc;n, một điều bạn cần lưu &yacute; l&agrave; m&agrave;n h&igrave;nh kh&ocirc;ng hỗ trợ cảm ứng, nhưng n&oacute; ho&agrave;n to&agrave;n c&oacute; thể được bỏ qua v&igrave; m&agrave;n h&igrave;nh sẽ đem đến cho bạn một h&igrave;nh ảnh r&otilde; n&eacute;t v&agrave; m&agrave;u sắc cực kỳ sống động.</p>\r\n<p><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-6.png\" /></p>\r\n<p>Ph&iacute;a tr&ecirc;n m&agrave;n h&igrave;nh l&agrave; một camera 720p, giống như hầu hết c&aacute;c camera của c&aacute;c mẫu Laptop kh&aacute;c, n&oacute; kh&ocirc;ng được qu&aacute; ch&uacute; trọng về chất lượng v&agrave; chỉ xem như d&ugrave;ng để chống ch&aacute;y m&agrave; th&ocirc;i. Mặt kh&aacute;c,&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>c&oacute; cảm biến ToF v&agrave; c&oacute; thể được sử dụng để đăng nhập Windows Hello nhanh ch&oacute;ng.</p>\r\n<h2><strong>Review Lenovo YOGA Slim 7 Carbon: Loa</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-4.jpg\" /></strong></p>\r\n<p>Loa của một chiếc Laptop ultrabook thường kh&ocirc;ng được qu&aacute; ch&uacute; trọng. Tuy nhi&ecirc;n, khi&nbsp;<strong>review Lenovo YOGA Slim 7 Carbon&nbsp;</strong>m&igrave;nh đ&atilde; kh&aacute; bất ngờ v&igrave; chất lượng của n&oacute;, loa của YOGA Slim 7 Carbon kh&aacute; &ldquo;ngon&rdquo;. Laptop trang bị hai loa tweeter v&agrave; loa đem đến &acirc;m trầm c&ugrave;ng khả năng ph&aacute;t ra &acirc;m thanh lớn m&agrave; kh&ocirc;ng đem lại cảm gi&aacute;c bị vỡ v&agrave; r&egrave; r&egrave; kh&oacute; chịu, bạn ho&agrave;n to&agrave;n c&oacute; thể xếp chiếc Laptop n&agrave;y l&ecirc;n tr&ecirc;n đối thủ của n&oacute; như những chiếc&nbsp;<strong>Laptop ASUS OLED</strong>&nbsp;mới nếu x&eacute;t về mặt &acirc;m thanh.</p>\r\n<h2><strong>B&agrave;n ph&iacute;m v&agrave; Touchpad</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-2.jpg\" /></strong></p>\r\n<p>B&agrave;n ph&iacute;m của&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>lại l&agrave; một điểm cộng lớn sau m&agrave;n h&igrave;nh của n&oacute;, v&agrave; nếu bạn l&agrave; một người d&ugrave;ng thường d&ugrave;ng b&agrave;n ph&iacute;m của Laptop v&agrave; c&oacute; tốc độ g&otilde; kh&aacute; nhanh, th&igrave; cấu tr&uacute;c b&agrave;n ph&iacute;m&nbsp;<strong>TrueStrike&nbsp;</strong>của&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>ch&iacute;nh l&agrave; một lợi thế lớn.&nbsp;</p>\r\n<p>B&agrave;n ph&iacute;m được thiết kế với c&aacute;c ph&iacute;m bấm c&oacute; diện t&iacute;ch lớn nhưng vẫn đảm bảo một Layout TKL th&ocirc;ng dụng, đi c&ugrave;ng đ&oacute; l&agrave; h&agrave;nh tr&igrave;nh nhấn 1.5 mm, cụm ph&iacute;m điều hướng ri&ecirc;ng biệt, TrueStrike cung cấp khả năng nhấn nhanh v&agrave; ch&iacute;nh x&aacute;c cho từng h&agrave;nh động của người d&ugrave;ng. Ngo&agrave;i ra, để đ&aacute;p ứng cho nhu cầu &ldquo;spam&rdquo; tốc độ cao cũng như sử dụng tổ hợp nhiều ph&iacute;m, TrueTrike c&oacute; khả năng anti-ghosting 100%, đảm bảo mọi thao t&aacute;c đều được ghi nhận một c&aacute;ch chuẩn x&aacute;c.</p>\r\n<p>Touchpad của ph&iacute;m đ&atilde; được mở rộng. N&oacute; hiện c&oacute; k&iacute;ch thước 12cm x 7,5cm, v&agrave; trở th&agrave;nh một trong những Touchpad lớn nhất so với c&aacute;c mẫu Laptop c&ugrave;ng ph&acirc;n kh&uacute;c. Trong l&uacute;c trải nghiệm để&nbsp;<strong>review</strong>&nbsp;<strong>Lenovo YOGA Slim 7 Carbon</strong>, touchpad của Laptop n&agrave;y lu&ocirc;n mượt m&agrave;, nhanh nhạy v&agrave; ch&iacute;nh x&aacute;c.</p>\r\n<h2><strong>Hiệu suất đ&aacute;ng gờm tr&ecirc;n một chiếc Laptop mỏng nhẹ</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-5.jpg\" /></strong></p>\r\n<p>Khi&nbsp;<strong>review Lenovo YOGA Slim 7 Carbon&nbsp;</strong>m&igrave;nh phải bất ngờ v&igrave; hiệu suất của chiếc Laptop được đ&aacute;nh gi&aacute; l&agrave; mỏng nhẹ nhất ph&acirc;n kh&uacute;c gi&aacute;. Laptop được trang bị&nbsp;<strong>bộ vi xử l&yacute; AMD Ryzen 5000 series</strong>&nbsp;với cấu h&igrave;nh t&ugrave;y chọn c&oacute; thể l&ecirc;n đến&nbsp;<strong>AMD Ryzen 7 5800U.</strong>&nbsp;V&agrave; kh&ocirc;ng hề ngoa khi những chiếc Laptop được trang bị Ryzen 5000 tr&ecirc;n thị trường được đ&oacute;n nhận một c&aacute;ch nồng nhiệt, kể cả Lenovo YOGA Slim 7 Carbon.</p>\r\n<p>Chiếc Laptop m&igrave;nh đang trải nghiệm c&oacute; cấu h&igrave;nh cao nhất l&agrave;:&nbsp;<strong>bộ xử l&yacute; AMD Ryzen 7 5800U với bộ nhớ 16GB, SSD 512GB v&agrave; đồ họa rời NVIDIA GeForce MX450</strong>. Thực sự rằng, sự kết hợp của AMD Ryzen 7 5800U v&agrave; Geforce MX450 của NVIDIA l&agrave; rất đ&aacute;ng gờm. N&oacute; đạt điểm cao ở hầu hết c&aacute;c điểm chuẩn được c&aacute;c trang kiểm tra điểm chuẩn PC, Laptop thực hiện. Hiệu suất đa l&otilde;i tr&ecirc;n cả Geekbench v&agrave; Cinebench l&agrave; một điểm nổi bật, thể hiện sức mạnh vượt bật của bộ chip mới nh&agrave; AMD trong khối lượng c&ocirc;ng việc đa luồng. V&agrave; với hiệu suất tr&ecirc;n l&agrave; v&ocirc; c&ugrave;ng ấn tượng khi n&oacute; nằm tr&ecirc;n một chiếc Laptop si&ecirc;u mỏng, nhẹ n&agrave;y.</p>\r\n<h2><strong>Review Lenovo YOGA Slim 7 Carbon: Tuổi thọ pin</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-2.png\" /></strong></p>\r\n<p>Nếu với th&ocirc;ng số cấu h&igrave;nh cao hơn, chắc hẳn c&aacute;c bạn sẽ nghĩ&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>c&oacute; thời lượng pin thấp hơn so với&nbsp;<strong>Lenovo YOGA Slim 7i Carbon.&nbsp;</strong>Tuy nhi&ecirc;n tr&ecirc;n thực tế,&nbsp;<strong>Lenovo YOGA Slim 7 Carbon&nbsp;</strong>vừa cung cấp khả năng hiệu suất cao hơn m&agrave; c&ograve;n c&oacute; thời lượng pin cho c&ocirc;ng việc văn ph&ograve;ng k&eacute;o d&agrave;i nhiều hơn 4 tiếng đồng hồ so với&nbsp;<strong>YOGA Slim 7i Carbon&nbsp;</strong>v&agrave; khi m&agrave;n h&igrave;nh được đặt ở độ s&aacute;ng tối đa 100%.</p>\r\n<p>Một điểm đ&aacute;ng ch&uacute; &yacute; nữa l&agrave; n&oacute; sạc rất nhanh. Chiếc laptop n&agrave;y tăng từ 0% pin l&ecirc;n khoảng 50% pin chỉ trong nửa giờ m&agrave; kh&ocirc;ng cần một c&agrave;i đặt n&agrave;o cả.</p>\r\n<h2><strong>Gần đến mức ho&agrave;n hảo</strong></h2>\r\n<p><strong><img src=\"https://cdn1.hoanghamobile.com/tin-tuc/wp-content/uploads/2022/11/Review-Lenovo-YOGA-Slim-7-Carbon-7.png\" /></strong></p>\r\n<p>Khi&nbsp;<strong>review Lenovo YOGA Slim 7 Carbon&nbsp;</strong>m&igrave;nh đ&atilde; cho n&oacute; một ti&ecirc;u đề l&agrave; gần đến mức ho&agrave;n hảo v&igrave; Yoga Slim 7i Carbon năm trước đ&atilde; đạt được giải thưởng C&ocirc;ng nghệ v&igrave; sự pha trộn tốt giữa hiệu suất, t&iacute;nh di động v&agrave; gi&aacute; cả. V&agrave; với&nbsp;<strong>YOGA Slim 7 Carbon&nbsp;</strong>năm nay cũng vậy, thậm ch&iacute; tốt hơn. Hiệu suất của m&aacute;y được cải thiện, m&agrave; vẫn giữ được t&iacute;nh di động; thậm ch&iacute; n&oacute; c&ograve;n c&oacute; m&agrave;n h&igrave;nh OLED đem đến trải nghiệm h&igrave;nh ảnh tuyệt đẹp. Nhưng c&oacute; lẽ, điều tuyệt vời nhất n&oacute; c&ograve;n c&oacute; mức gi&aacute; cực kỳ cạnh tranh trong c&aacute;c sản phẩm c&ugrave;ng ph&acirc;n kh&uacute;c.</p>\r\n<p>Nhưng n&oacute; cũng c&oacute; một số điểm, cũng ch&iacute;nh l&agrave; l&yacute; do l&agrave;m cho n&oacute; gần đến mức ho&agrave;n hảo đ&oacute; ch&iacute;nh l&agrave; thiếu cổng thunderbolt. V&agrave; một số thiếu s&oacute;t nhỏ như về Webcam m&agrave; th&ocirc;i.&nbsp;V&agrave; m&igrave;nh nghĩ chắc chắn rằng n&oacute; vẫn sẽ nằm trong mục &ldquo;những laptop di động tốt nhất năm 2022&rdquo;.</p>\r\n<p>&nbsp;</p>', 19, '2022-11-15 08:08:05', '2022-11-17 06:26:46', 'review-lenovo-yoga-slim-7-carbon-gan-den-muc-hoan-hao');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts_category`
--

CREATE TABLE `posts_category` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_post` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `posts_category`
--

INSERT INTO `posts_category` (`id`, `category_post`, `created_at`, `updated_at`) VALUES
(18, 'Tin tức', '2022-11-17 06:25:53', '2022-11-17 06:25:53'),
(19, 'Công nghệ', '2022-11-17 06:26:28', '2022-11-17 06:26:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `properties` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `thumbnail`, `product_desc`, `product_detail`, `category_product_id`, `user_id`, `created_at`, `updated_at`, `product_status`, `slug`, `properties`) VALUES
(7, 'Điện thoại di động Xiaomi 12 - Chính hãng', '2000000', 'public/uploads/product/mi-12.png', '<p>Điện thoại di động Xiaomi 12 - Ch&iacute;nh h&atilde;ng</p>', '<p>Điện thoại di động Xiaomi 12 - Ch&iacute;nh h&atilde;ng</p>', 37, 1, '2022-10-27 07:49:50', '2022-10-29 06:34:31', '1', 'san-pham-1', '1'),
(8, 'Điện thoại di động Samsung Galaxy S22 Ultra', '2000000', 'public/uploads/product/Galaxy-S22-Ultra-Burgundy-600x600.jpg', '<h1>Điện thoại di động Samsung Galaxy S22 Ultra - 8GB/128GB - Ch&iacute;nh h&atilde;ng</h1>', '<h1>Điện thoại di động Samsung Galaxy S22 Ultra - 8GB/128GB - Ch&iacute;nh h&atilde;ng</h1>', 36, 1, '2022-10-28 08:31:36', '2022-10-28 21:02:09', '1', 'samsung-galaxy-s22', '1'),
(9, 'Điện thoại di động OPPO Reno6 Z 5G', '6090000', 'public/uploads/product/reno6-z.png', '<p>Điện thoại di động OPPO Reno6 Z 5G&nbsp;</p>', '<p>Điện thoại di động OPPO Reno6 Z 5G&nbsp;</p>', 47, 1, '2022-10-28 09:07:14', '2022-10-29 01:45:25', '1', 'dien-thoai-di-dong-oppo-reno6-z-5g', '1'),
(10, 'Laptop HP Gaming VICTUS 16 - d0198TX - 4R0U0PA', '26890000', 'public/uploads/product/hp-victus-16-d0292tx-i5-5z9r3pa-1.jpeg', '<p>Laptop HP Gaming VICTUS 16 - d0198TX - 4R0U0PA (i7-11800H/8GB RAM/512GB SSD+32GB SSD/RTX 3050Ti 4GB/16.1\"FHD/Win 11) - Ch&iacute;nh h&atilde;ng</p>', '<p>Laptop HP Gaming VICTUS 16 - d0198TX - 4R0U0PA (i7-11800H/8GB RAM/512GB SSD+32GB SSD/RTX 3050Ti 4GB/16.1\"FHD/Win 11) - Ch&iacute;nh h&atilde;ng</p>', 32, 1, '2022-10-28 19:55:26', '2022-10-29 01:29:11', '1', 'laptop-hp-gaming-victus-16-d0198tx-4r0u0pa-i7-11800h8gb-ram512gb-ssd32gb-ssdrtx-3050ti-4gb161fhdwin-11-chinh-hang', '0'),
(11, 'Laptop Dell Inspiron 16 5620 i5P165W11SLU  i5', '22590000', 'public/uploads/product/dell-inspiron-16-5620-i5-n6i5003w1-060722-063545-600x600.jpg', '<p>Laptop Dell Inspiron 16 5620 i5P165W11SLU i5-1240P/16GB/512GB/Intel Iris Xe/16.0 inch FHD+/ Win 11/Office/Bạc - Ch&iacute;nh h&atilde;ng</p>', '<p>Laptop Dell Inspiron 16 5620 i5P165W11SLU i5-1240P/16GB/512GB/Intel Iris Xe/16.0 inch FHD+/ Win 11/Office/Bạc - Ch&iacute;nh h&atilde;ng</p>', 33, 1, '2022-10-28 19:57:00', '2022-10-29 01:29:31', '1', 'laptop-dell-inspiron-16-5620-i5p165w11slu-i5-1240p16gb512gbintel-iris-xe160-inch-fhd-win-11officebac-chinh-hang', '0'),
(12, 'Laptop Gaming Acer Nitro 5 Tiger AN515-58-773Y', '28490000', 'public/uploads/product/acer-nitro-5-tiger-an515-58-773y-i7-nhqfksv001-thumb-600x600.jpg', '<p>Laptop Gaming Acer Nitro 5 Tiger AN515-58-773Y (i7-12700H/8GB/512GB PCIE/RTX3050Ti/15.6 IPS 144Hz/WIN11/ĐEN) (NH.QFKSV.001) - Ch&iacute;nh h&atilde;ng</p>', '<p>Laptop Gaming Acer Nitro 5 Tiger AN515-58-773Y (i7-12700H/8GB/512GB PCIE/RTX3050Ti/15.6 IPS 144Hz/WIN11/ĐEN) (NH.QFKSV.001) - Ch&iacute;nh h&atilde;ng</p>', 40, 1, '2022-10-28 20:01:35', '2022-10-29 01:29:48', '1', 'laptop-gaming-acer-nitro-5-tiger-an515-58-773y-i7-12700h8gb512gb-pciertx3050ti156-ips-144hzwin11den-nhqfksv001-chinh-hang', '1'),
(13, 'Laptop Macbook Pro M2 13\" 2022 - 16GB/256GB', '36990000', 'public/uploads/product/apple-macbook-pro-13-inch-m2-2022-xam-600x600.jpg', '<p>Laptop Macbook Pro M2 13\" 2022 - 16GB/256GB - Ch&iacute;nh h&atilde;ng Apple Việt Nam</p>', '<p>Laptop Macbook Pro M2 13\" 2022 - 16GB/256GB - Ch&iacute;nh h&atilde;ng Apple Việt Nam</p>', 48, 1, '2022-10-28 20:04:29', '2022-10-29 01:30:01', '1', 'laptop-macbook-pro-m2-13-2022-16gb256gb-chinh-hang-apple-viet-nam', '1'),
(14, 'Điện thoại iPhone 13 Pro Max 128GB', '28490000', 'public/uploads/product/iphone-13-pro-max-xanh-la-thumb-600x600.jpg', '<p>Điện thoại iPhone 13 Pro Max 128GB</p>', '<p>Điện thoại iPhone 13 Pro Max 128GB</p>', 30, 1, '2022-10-28 20:33:19', '2022-10-28 20:33:19', '1', 'dien-thoai-iphone-13-pro-max-128gb', '0'),
(15, 'Điện thoại iPhone 14 Plus 128GB', '26490000', 'public/uploads/product/iPhone-14-plus-thumb-den-600x600.jpg', '<h1>Điện thoại iPhone 14 Plus 128GB</h1>\r\n<p>&nbsp;</p>', '<p><strong>C&ocirc;ng nghệ m&agrave;n h&igrave;nh::</strong>&nbsp;Super Retina XDR</p>\r\n<p><strong>Độ ph&acirc;n giải::</strong>&nbsp;2556 x 1179-pixel</p>\r\n<p><strong>M&agrave;n h&igrave;nh rộng::</strong>&nbsp;OLED 6.1‑inch</p>\r\n<p><strong>Độ ph&acirc;n giải:</strong>&nbsp;48MP x 12MP x 12MP, 12MP</p>\r\n<p><strong>Hệ điều h&agrave;nh:</strong>&nbsp;iOS 16</p>\r\n<p><strong>Chip xử l&yacute; (CPU):</strong>&nbsp;A16 Bionic</p>\r\n<p><strong>Bộ nhớ trong (ROM):</strong>&nbsp;128GB</p>\r\n<p><strong>RAM:</strong>&nbsp;6 GB</p>\r\n<p><strong>Mạng di động:</strong>&nbsp;5G (sub ‑ 6 GHz v&agrave; mmWave) với 4x4 MIMO, Gigabit LTE với 4x4 MIMO v&agrave; LAA</p>\r\n<p><strong>Số khe sim:</strong>&nbsp;1 eSIM, 1 SIM vật l&yacute;</p>\r\n<p>&nbsp;</p>', 30, 1, '2022-10-28 20:42:27', '2022-10-29 20:09:21', '1', 'dien-thoai-iphone-14-plus-128gb', '0'),
(16, 'Laptop Lenovo Gaming Legion 5 15ITH6', '32990000', 'public/uploads/product/lenovo-01.png', '<p>Laptop Lenovo Gaming Legion 5 15ITH6 i7 11800H/16GB/512GB/4GB RTX3050Ti/165Hz/Win11 (82JK00FNVN)</p>', '<p>Laptop Lenovo Gaming Legion 5 15ITH6 i7 11800H/16GB/512GB/4GB RTX3050Ti/165Hz/Win11 (82JK00FNVN)</p>', 49, 1, '2022-10-28 20:58:58', '2022-10-29 02:31:14', '1', 'laptop-lenovo-gaming-legion-5-15ith6-i7-11800h16gb512gb4gb-rtx3050ti165hzwin11-82jk00fnvn', '0'),
(17, 'Điện thoại Samsung Galaxy Z Flip4 128GB', '20990000', 'public/uploads/product/samsung-galaxy-z-flip4-5g-128gb-thumb-tim-600x600.jpg', '<p>Điện thoại Samsung Galaxy Z Flip4 128GB</p>', '<p>Điện thoại Samsung Galaxy Z Flip4 128GB</p>', 36, 1, '2022-10-29 01:58:44', '2022-10-29 01:58:44', '1', 'dien-thoai-samsung-galaxy-z-flip4-128gb', '1'),
(18, 'Điện thoại Samsung Galaxy Z Fold4', '37990000', 'public/uploads/product/samsung-galaxy-z-fold4-kem-256gb-600x600.jpg', '<p>Điện thoại Samsung Galaxy Z Fold4</p>', '<p>Điện thoại Samsung Galaxy Z Fold4</p>', 36, 1, '2022-10-29 02:01:08', '2022-10-29 02:01:08', '1', 'dien-thoai-samsung-galaxy-z-fold4', '1'),
(19, 'Laptop Apple MacBook Air M2 2022 8GB/256GB/8-core GPU', '32990000', 'public/uploads/product/apple-macbook-air-m2-2022-xam-600x600.jpg', '<p>aptop Apple MacBook Air M2 2022 8GB/256GB/8-core GPU</p>', '<p>aptop Apple MacBook Air M2 2022 8GB/256GB/8-core GPU</p>', 48, 1, '2022-10-29 02:05:59', '2022-10-29 02:06:40', '1', 'aptop-apple-macbook-air-m2-2022-8gb256gb8-core-gpu', '0'),
(20, 'Laptop Lenovo IdeaPad Gaming 3 15IHU6', '17390000', 'public/uploads/product/lenovo-ideapad-gaming-3-15ihu6-i5-82k10178vn-100622-060818-600x600.jpg', '<p>Laptop Lenovo IdeaPad Gaming 3 15IHU6 i5 11300H/8GB/512GB/4GB GTX1650/120Hz/Win11</p>', '<p>Laptop Lenovo IdeaPad Gaming 3 15IHU6 i5 11300H/8GB/512GB/4GB GTX1650/120Hz/Win11</p>', 49, 1, '2022-10-29 02:11:40', '2022-10-29 02:31:14', '1', 'laptop-lenovo-ideapad-gaming-3-15ihu6-i5-11300h8gb512gb4gb-gtx1650120hzwin11', '0'),
(21, 'Laptop Lenovo Yoga Slim 7 14IAL7', '27890000', 'public/uploads/product/lenovo-yoga-slim-7-14ial7-i5-82qe000rvn-thumb-600x600.jpg', '<p>Laptop Lenovo Yoga Slim 7 14IAL7 i5 1240P/16GB/512GB/Touch/Pen/Win11</p>', '<p>Laptop Lenovo Yoga Slim 7 14IAL7 i5 1240P/16GB/512GB/Touch/Pen/Win11</p>', 49, 1, '2022-10-29 02:13:32', '2022-10-29 02:14:40', '1', 'laptop-lenovo-yoga-slim-7-14ial7-i5-1240p16gb512gbtouchpenwin11', '1'),
(22, 'iPhone 14 Pro Max 128GB | Chính hãng VN/A', '32490000', 'public/uploads/product/iphone-14-pro-max-den-thumb-600x600.jpg', '<h1 style=\"text-align: center;\">Mua iPhone 14 Pro Max ch&iacute;nh h&atilde;ng VN/A, gi&aacute; rẻ tại Unimart</h1>\r\n<p style=\"text-align: justify;\">iPhone 14 Pro Max VN/A l&agrave; d&ograve;ng sản phẩm cao cấp nhất nằm trong thế hệ iPhone 14 Series mới vừa được ra mắt c&ugrave;ng với nhiều n&acirc;ng cấp về ngoại h&igrave;nh v&agrave; t&iacute;nh năng, hứa hẹn sẽ l&agrave; d&ograve;ng sản phẩm đột ph&aacute; trong v&agrave;i năm trở lại đ&acirc;y của Apple.</p>\r\n<p><img src=\"https://admin.hoanghamobile.com/Uploads/2022/10/05/11.jpg\" alt=\"\" width=\"1049\" height=\"590\" /></p>\r\n<p style=\"text-align: center;\"><em><span lang=\"vi\">iPhone 14 Pro Max VN/A</span></em></p>\r\n<h2><span lang=\"vi\">Ph&aacute; vỡ thiết kế notch cổ điển</span></h2>\r\n<p style=\"font-weight: 400; text-align: justify;\">Chiếc iPhone 14 Pro Max VN/A sở hữu m&agrave;n h&igrave;nh Super Retina XDR mới với ProMotion c&oacute; k&iacute;ch thước 6.7 inch. Tần số qu&eacute;t m&agrave;n h&igrave;nh sẽ giảm xuống 1 Hz để tiết kiệm pin, trong khi h&igrave;nh nền được l&agrave;m mờ. M&agrave;n h&igrave;nh ti&ecirc;n tiến cũng mang lại mức độ s&aacute;ng HDR cao nhất tương tự như Pro Display XDR v&agrave; ​​độ s&aacute;ng đỉnh ngo&agrave;i trời cao nhất trong điện thoại th&ocirc;ng minh: l&ecirc;n đến 2000 nits, s&aacute;ng gấp đ&ocirc;i so với người tiền nhiệm.</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">M&agrave;n h&igrave;nh trước l&agrave;m từ chất liệu Ceramic Shield - cứng hơn bất kỳ loại k&iacute;nh điện thoại th&ocirc;ng minh n&agrave;o - v&agrave; được bảo vệ khỏi c&aacute;c sự cố tr&agrave;n v&agrave; tai nạn th&ocirc;ng thường với khả năng chống nước v&agrave; bụi.</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">M&agrave;n h&igrave;nh Dynamic Island mới tr&ecirc;n d&ograve;ng iPhone 14 Pro được coi l&agrave; &yacute; tưởng thiết kế s&aacute;ng tạo, đem đến trải nghiệm độc đ&aacute;o. Apple đ&atilde; thay thế phần notch tr&ecirc;n d&ograve;ng sản phẩm &zwnj;iPhone 14 Pro&zwnj; bằng lỗ khuyết vi&ecirc;n thuốc v&agrave; đục lỗ. Một chi tiết mới quan trọng của việc thay thế notch xuất hiện trong tuần n&agrave;y l&agrave; khi thiết bị được sử dụng, c&aacute;c lỗ h&igrave;nh vi&ecirc;n thuốc v&agrave; lỗ đục lỗ sẽ hợp nhất bằng kỹ thuật số th&agrave;nh h&igrave;nh chữ i d&agrave;i hơn. Phần cắt n&agrave;y được Apple d&ugrave;ng để hiển thị th&ocirc;ng tin như c&aacute;c th&ocirc;ng b&aacute;o về quyền ri&ecirc;ng tư của iOS v&agrave; cụm cảm biến cho FaceID</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">Ngo&agrave;i ra, iPhone 14 Pro Max VN/A c&ograve;n c&oacute; t&iacute;nh năng Always On Display hay m&agrave;n h&igrave;nh lu&ocirc;n bật, đ&acirc;y l&agrave; một trong những t&iacute;nh năng kh&aacute; th&uacute; vị tr&ecirc;n c&aacute;c d&ograve;ng điện thoại hiện nay. T&iacute;nh năng n&agrave;y kh&ocirc;ng chỉ gi&uacute;p bạn nhận được th&ocirc;ng b&aacute;o từ c&aacute;c ứng dụng như đồng hồ, lịch, tin nhắn, cuộc gọi nhỡ, ứng dụng,... kể cả khi m&agrave;n h&igrave;nh điện thoại đ&atilde; tắt m&agrave; c&ograve;n gi&uacute;p điện thoại tiết kiệm pin đ&aacute;ng kể.</p>\r\n<h2><span lang=\"vi\">N&acirc;ng cấp đ&aacute;ng kể về camera</span></h2>\r\n<p style=\"text-align: justify;\"><span lang=\"vi\">Một trong những n&acirc;ng cấp m&agrave; người d&ugrave;ng tr&ocirc;ng đợi nhất từ d&ograve;ng iPhone 14 đ&oacute; ch&iacute;nh l&agrave; camera. Sau nhiều năm camera dặm ch&acirc;n ở con số 12MP, độ ph&acirc;n giải camera ch&iacute;nh của iPhone 14 Pro Max VN/A đ&atilde; được n&acirc;ng cấp l&ecirc;n th&agrave;nh 48MP c&ugrave;ng điểm ảnh 1,4&micro;m. Sự n&acirc;ng cấp n&agrave;y cho ph&eacute;p camera thu được nhiều &aacute;nh s&aacute;ng hơn khi chụp ảnh trong điều kiện &aacute;nh s&aacute;ng yếu.</span></p>\r\n<p><span lang=\"vi\"><img src=\"https://admin.hoanghamobile.com/Uploads/2022/10/05/22.jpg\" alt=\"\" width=\"1050\" height=\"591\" /></span></p>\r\n<p style=\"text-align: center;\"><span lang=\"vi\"><em>iPhone 14 Pro Max VN/A c&oacute; n&acirc;ng cấp đ&aacute;ng kể về camera</em></span></p>\r\n<p style=\"font-weight: 400; text-align: justify;\">Ngo&agrave;i ra, điện thoại c&ograve;n hỗ trợ quay video 8K (ở tốc độ l&ecirc;n đến 60 khung h&igrave;nh/gi&acirc;y), kh&ocirc;ng chỉ đem lại h&igrave;nh ảnh sắc n&eacute;t hơn (như tăng chất lượng tr&ecirc;n video YouTube) m&agrave; c&ograve;n cho ph&eacute;p c&aacute;c nh&agrave; l&agrave;m phim cắt, ổn định v&agrave; điều chỉnh lại cảnh quay sau khi n&oacute; được quay.</p>\r\n<ul style=\"text-align: justify;\">\r\n<li style=\"font-weight: 400;\">M&aacute;y ảnh ch&iacute;nh được n&acirc;ng cấp l&ecirc;n th&agrave;nh 48MP c&ugrave;ng điểm ảnh 1,4&micro;m, đi k&egrave;m pixel-binning (kết hợp pixel với nhau) cho ph&eacute;p camera thu được nhiều &aacute;nh s&aacute;ng hơn v&agrave; giảm nhiễu</li>\r\n<li style=\"font-weight: 400;\">M&aacute;y ảnh 12MP Ultra Wide mới với điểm ảnh 1,4 &micro;m pixel, mang lại h&igrave;nh ảnh sắc n&eacute;t hơn với nhiều chi tiết hơn, cải thiện khả năng chụp ảnh macro vốn đ&atilde; mạnh mẽ.</li>\r\n<li style=\"font-weight: 400;\">M&aacute;y ảnh tele cải tiến c&oacute; khả năng zoom quang học 3x.</li>\r\n<li style=\"font-weight: 400;\">Một camera TrueDepth ph&iacute;a trước mới với khẩu độ &fnof; / 1.9 cho ph&eacute;p chụp ảnh v&agrave; quay video trong điều kiện &aacute;nh s&aacute;ng yếu tốt hơn. Sử dụng lấy n&eacute;t tự động lần đầu ti&ecirc;n, n&oacute; c&oacute; thể lấy n&eacute;t nhanh hơn nữa trong điều kiện &aacute;nh s&aacute;ng yếu v&agrave; chụp ảnh nh&oacute;m từ xa hơn.</li>\r\n<li style=\"font-weight: 400;\">Đ&egrave;n flash True Tone th&iacute;ch ứng mới đ&atilde; được thiết kế lại ho&agrave;n to&agrave;n với một d&atilde;y ch&iacute;n đ&egrave;n LED thay đổi kiểu dựa tr&ecirc;n độ d&agrave;i ti&ecirc;u cự đ&atilde; chọn.</li>\r\n<li style=\"font-weight: 400;\">Hỗ trợ chụp ảnh ti&ecirc;n tiến như Chế độ ban đ&ecirc;m, Smart HDR 4, Chế độ ch&acirc;n dung với &Aacute;nh s&aacute;ng ch&acirc;n dung, Chế độ ban đ&ecirc;m Ảnh ch&acirc;n dung, Kiểu chụp ảnh để c&aacute; nh&acirc;n h&oacute;a giao diện của mọi bức ảnh v&agrave; Apple ProRAW.</li>\r\n<li style=\"font-weight: 400;\">Chế độ Action mới cho video tr&ocirc;ng cực kỳ mượt m&agrave; c&oacute; thể giảm độ rung, cho ra những khung h&igrave;nh mượt m&agrave; sống động</li>\r\n<li style=\"font-weight: 400;\">Chế độ Cinematic, hiện c&oacute; sẵn ở 4K ở tốc độ 30 khung h&igrave;nh / gi&acirc;y v&agrave; 4K ở tốc độ 24 khung h&igrave;nh / gi&acirc;y.</li>\r\n<li style=\"font-weight: 400;\">T&iacute;nh năng định dạng video chuy&ecirc;n nghiệp, bao gồm ProRes3 v&agrave; Dolby Vision HDR đầu cuối.</li>\r\n</ul>\r\n<h2><span lang=\"vi\">Bộ vi xử l&yacute; A16 cực xịn</span></h2>\r\n<p style=\"text-align: justify;\"><span lang=\"vi\">iPhone 14 Pro Max VN/A sử dụng bộ vi xử l&yacute; Apple A16 Bionic được xử l&yacute; tr&ecirc;n tiến tr&igrave;nh 4nm. Với bộ xử l&yacute; neural 16 nh&acirc;n tr&ecirc;n chip n&agrave;y, b&ecirc;n cạnh bộ xử l&yacute; m&agrave;n h&igrave;nh ho&agrave;n to&agrave;n mới để hỗ trợ đẩy tần số qu&eacute;t xuống 1Hz, xử l&yacute; t&iacute;nh năng always-on v&agrave; gi&uacute;p Dynamic Island hoạt động mượt m&agrave;.Thiết bị c&oacute; RAM 6GB sử dụng c&ocirc;ng nghệ LPDDR5 cải tiến về tốc độ truyền v&agrave; điện năng ti&ecirc;u thụ.</span></p>\r\n<p><span lang=\"vi\"><img src=\"https://admin.hoanghamobile.com/Uploads/2022/10/05/33.jpg\" alt=\"\" width=\"1051\" height=\"1471\" /></span></p>\r\n<p style=\"text-align: center;\"><span lang=\"vi\"><em>iPhone 14 Pro Max VN/A</em></span></p>\r\n<h2><span lang=\"vi\">T&iacute;nh năng điện thoại vệ tinh</span></h2>\r\n<p style=\"font-weight: 400; text-align: justify;\">Điểm độc đ&aacute;o tr&ecirc;n thế hệ&nbsp;<a href=\"https://hoanghamobile.com/dien-thoai-di-dong/iphone/iphone-14-series\">iPhone 14 Series</a>&nbsp;ch&iacute;nh l&agrave; điện thoại vệ tinh hỗ trợ người d&ugrave;ng trong việc li&ecirc;n lạc bằng c&aacute;ch kết nối với c&aacute;c trạm vệ tinh xoay quanh quỹ đạo m&agrave; kh&ocirc;ng cần s&oacute;ng của nh&agrave; mạng.</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">iPhone 14 Pro Max VN/A c&oacute; dung lượng 4.323 mAh &ndash; thấp hơn một ch&uacute;t so với mức 4.352 mAh của 13 Pro Max. Ngo&agrave;i ra, thiết bị được trang bị sạc nhanh với c&ocirc;ng suất 30W, cao hơn đ&aacute;ng kể so với mức sạc 20W cũ.</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">iPhone 14 Pro Max VN/A hiện l&agrave; chiếc flagship c&oacute; trọng lượng nặng nhất tr&ecirc;n thị trường với khối lượng 255 gram, cao hơn 15 gram so với thế hệ trước. Người d&ugrave;ng c&oacute; t&ugrave;y chọn c&aacute;c phi&ecirc;n bản dung lượng gồm 128 GB, 256 GB, 512 GB v&agrave; 1TB. Thiết bị sử dụng phần khung titan thay v&igrave; th&eacute;p kh&ocirc;ng gỉ, mang đến một chiếc iPhone mạnh mẽ hơn, nhẹ hơn v&agrave; chống trầy tốt hơn, d&ugrave; l&agrave;m tăng khối lượng.</p>\r\n<p style=\"font-weight: 400; text-align: justify;\">iPhone 14 Pro Max VN/A sẽ c&oacute; c&aacute;c lựa chọn m&agrave;u sắc: x&aacute;m than ch&igrave; (Graphite), bạc (Silver), v&agrave;ng (Gold), t&iacute;m (Purple), nhưng kh&ocirc;ng c&oacute; phi&ecirc;n bản m&agrave;u xanh Sierra Blue như năm ngo&aacute;i.</p>', '<p><strong>C&ocirc;ng nghệ m&agrave;n h&igrave;nh::</strong>&nbsp;Super Retina XDR</p>\r\n<p><strong>Độ ph&acirc;n giải::</strong>&nbsp;2796 x 1290 pixel</p>\r\n<p><strong>M&agrave;n h&igrave;nh rộng::</strong>&nbsp;OLED 6.7‑inch</p>\r\n<p><strong>Độ ph&acirc;n giải:</strong>&nbsp;48MP x 12MP x 12MP, 12MP</p>\r\n<p><strong>Hệ điều h&agrave;nh:</strong>&nbsp;iOS 16</p>\r\n<p><strong>Chip xử l&yacute; (CPU):</strong>&nbsp;A16 Bionic</p>\r\n<p><strong>Bộ nhớ trong (ROM):</strong>&nbsp;128GB</p>\r\n<p><strong>RAM:</strong>&nbsp;6 GB</p>\r\n<p><strong>Mạng di động:</strong>&nbsp;5G (sub ‑ 6 GHz v&agrave; mmWave) với 4x4 MIMO, Gigabit LTE với 4x4 MIMO v&agrave; LAA</p>\r\n<p><strong>Số khe sim:</strong>&nbsp;1 eSIM, 1 SIM vật l&yacute;</p>', 30, 2, '2022-10-30 05:17:07', '2022-11-14 19:42:18', '1', 'iphone-14-pro-max-128gb-chinh-hang-vna', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product_colors`
--

CREATE TABLE `product_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `amout` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product_colors`
--

INSERT INTO `product_colors` (`id`, `name`, `color_code`, `product_id`, `amout`, `created_at`, `updated_at`) VALUES
(11, 'Đen', '#000000', 15, '100', '2022-10-29 21:11:14', '2022-10-29 21:11:14'),
(12, 'Tím', '#f316eb', 15, '100', '2022-10-29 21:11:34', '2022-10-29 21:20:32'),
(13, 'Xanh dương', '#1585cb', 15, '100', '2022-10-29 21:11:58', '2022-10-29 21:11:58'),
(14, 'Đỏ', '#e41b1b', 15, '100', '2022-10-29 21:12:19', '2022-10-29 21:12:19'),
(15, 'Vàng Gold', '#e0a910', 22, '100', '2022-10-30 05:19:07', '2022-10-30 05:19:07'),
(16, 'Đen', '#000000', 22, '100', '2022-10-30 05:19:17', '2022-10-30 05:19:17'),
(17, 'Tím', '#b115d1', 22, '100', '2022-10-30 05:19:34', '2022-10-30 05:19:34'),
(18, 'Bạc', '#c7c2c2', 22, '100', '2022-10-30 05:19:56', '2022-10-30 05:19:56'),
(19, 'Đen', '#000000', 18, '100', '2022-11-01 05:13:17', '2022-11-01 05:13:17'),
(20, 'tím', '#d80eb3', 17, '10', '2022-11-01 05:13:40', '2022-11-01 05:13:40');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_group` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `roles`
--

INSERT INTO `roles` (`id`, `name`, `role_group`, `created_at`, `updated_at`) VALUES
(6, 'Admin', '[\"admin.dashboard.index\",\"admin.profile\",\"admin.profile.update\",\"admin.change\",\"admin.admin.show\",\"admin.user.list\",\"admin.user.add\",\"admin.user.role\",\"admin.user.store\",\"admin.delete_user\",\"admin.user.action\",\"admin.user.edit\",\"admin.user.update\",\"admin.user.forcedelete\",\"admin.user.restore\",\"admin.post.list\",\"admin.Post.add\",\"admin.post.store\",\"admin.post.delete\",\"admin.post.action\",\"admin.post.edit\",\"admin.post.update\",\"admin.category_post.delete\",\"admin.category_post.edit\",\"admin.category_post.update\",\"admin.page.delete\",\"admin.page.edit\",\"admin.page.update\",\"admin.categoryproduct.delete\",\"admin.categoryproduct.edit\",\"admin.categoryproduct.update\",\"admin.gallery.add\",\"admin.color.delete\",\"admin.color.edit\",\"admin.color.update\",\"admin.product.delete\",\"admin.product.edit\",\"admin.product.update\",\"admin.color.show\",\"admin.order.delete\",\"admin.order.detail\",\"admin.order.update\",\"admin.role.delete\",\"admin.role.edit\",\"admin.role.update\"]', '2022-11-02 06:39:20', '2022-11-02 19:05:25'),
(7, 'Staff', '[\"admin.post.list\",\"admin.Post.add\",\"admin.post.store\",\"admin.post.delete\",\"admin.post.action\",\"admin.post.edit\",\"admin.post.update\"]', '2022-11-02 06:41:44', '2022-11-02 19:31:13'),
(8, 'Admin Root', '[\"admin.error.show\",\"admin.dashboard.index\",\"admin.show\",\"admin.user.list\",\"admin.user.add\",\"admin.user.role\",\"admin.user.store\",\"admin.delete_user\",\"admin.user.action\",\"admin.user.edit\",\"admin.user.update\",\"admin.user.forcedelete\",\"admin.user.restore\",\"admin.post.list\",\"admin.Post.add\",\"admin.post.store\",\"admin.post.delete\",\"admin.post.action\",\"admin.post.edit\",\"admin.post.update\",\"admin.post.cat\",\"admin.category-post.store\",\"admin.category_post.delete\",\"admin.category_post.edit\",\"admin.category_post.update\",\"admin.page.list\",\"admin.page.add\",\"admin.page.store\",\"admin.page.delete\",\"admin.page.edit\",\"admin.page.update\",\"admin.page.action\",\"admin.product.cat\",\"admin.category-product.store\",\"admin.categoryproduct.delete\",\"admin.categoryproduct.edit\",\"admin.categoryproduct.update\",\"admin.gallery.add\",\"admin.color.delete\",\"admin.color.edit\",\"admin.color.update\",\"admin.product.list\",\"admin.product.add\",\"admin.product.store\",\"admin.product.delete\",\"admin.product.edit\",\"admin.product.update\",\"admin.color.show\",\"admin.product.action\",\"admin.order.list\",\"admin.order.action\",\"admin.order.delete\",\"admin.order.detail\",\"admin.order.update\",\"admin.role.list\",\"admin.role.add\",\"admin.role.store\",\"admin.role.delete\",\"admin.role.edit\",\"admin.role.update\",\"admin.slider.list\",\"admin.slider.store\",\"admin.slider.delete\"]', '2022-11-02 08:10:42', '2022-11-03 07:08:17'),
(9, 'Post', '[\"admin.post.list\",\"admin.Post.add\",\"admin.post.store\",\"admin.post.delete\",\"admin.post.action\",\"admin.post.edit\",\"admin.post.update\"]', '2022-11-02 19:09:27', '2022-11-02 20:47:16'),
(10, 'dashboard', '[\"admin.dashboard.index\",\"admin.profile\",\"admin.profile.update\",\"admin.change\",\"admin.show\"]', '2022-11-02 21:46:39', '2022-11-02 21:46:39'),
(11, 'Product', '[\"admin.product.cat\",\"admin.category-product.store\",\"admin.categoryproduct.delete\",\"admin.categoryproduct.edit\",\"admin.categoryproduct.update\",\"admin.gallery.add\",\"admin.color.delete\",\"admin.color.edit\",\"admin.color.update\",\"admin.product.list\",\"admin.product.add\",\"admin.product.store\",\"admin.product.delete\",\"admin.product.edit\",\"admin.product.update\",\"admin.color.show\",\"admin.product.action\",\"admin.order.list\",\"admin.order.action\",\"admin.order.delete\",\"admin.order.detail\",\"admin.order.update\"]', '2022-11-03 02:00:36', '2022-11-03 02:02:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `role_user`
--

CREATE TABLE `role_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(8, 16, 7, '2022-11-02 19:50:10', '2022-11-02 19:50:10'),
(9, 16, 9, '2022-11-02 19:50:10', '2022-11-02 19:50:10'),
(26, 1, 8, '2022-11-03 01:18:19', '2022-11-03 01:18:19'),
(45, 3, 8, '2022-11-03 01:58:48', '2022-11-03 01:58:48'),
(48, 2, 9, '2022-11-03 02:02:23', '2022-11-03 02:02:23'),
(49, 2, 10, '2022-11-03 02:02:23', '2022-11-03 02:02:23'),
(50, 2, 11, '2022-11-03 02:02:23', '2022-11-03 02:02:23'),
(51, 17, 9, '2022-11-03 02:09:28', '2022-11-03 02:09:28'),
(52, 17, 10, '2022-11-03 02:09:28', '2022-11-03 02:09:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `sliders`
--

INSERT INTO `sliders` (`id`, `name`, `thumbnail`, `created_at`, `updated_at`) VALUES
(8, 'anh-messi-4k-dep-14-15-58-06.jpg', 'public/uploads/slider/634226594.6342265.png', '2022-11-03 08:19:44', '2022-11-03 08:43:42'),
(9, '44081501_2208855219395473_5656062283441242112_n.jpg', 'public/uploads/slider/44081501_2208855219395473_5656062283441242112_n.jpg', '2022-11-03 08:26:07', '2022-11-03 08:26:07'),
(10, '72690200_2460214357592890_5438675996972679168_n.jpg', 'public/uploads/slider/72690200_2460214357592890_5438675996972679168_n.jpg', '2022-11-03 08:26:17', '2022-11-03 08:26:17'),
(11, '1100694.png', 'public/uploads/slider/1100694.png', '2022-11-15 08:34:30', '2022-11-15 08:34:30'),
(12, 'dich-le-nhiet-basina3-crop-1639106593372.png', 'public/uploads/slider/dich-le-nhiet-basina3-crop-1639106593372.png', '2022-11-15 08:34:47', '2022-11-15 08:34:47');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Cao Hải Đăng', 'dang48691216@gmail.com', NULL, '$2y$10$6dzVyDNSOIrXVddjiSUapuXPs.mC.Mka1N4urPFmS2SXh00zAb1oK', NULL, '2022-10-16 01:12:48', '2022-11-03 01:18:19', NULL),
(2, 'Cao Giao Bảo Sề', 'bao19392633128@gmail.com', NULL, '$2y$10$Zq0VaQ3nSFeaKMYFNKYF.e88XODOqhlHxnugaIFm1NzclaTITrzVS', NULL, '2022-10-16 06:40:07', '2022-11-03 02:02:23', NULL),
(3, 'Cao Gia Bảo', 'ngoanthhp@gmail.com', NULL, '$2y$10$4uKRwtue5w2dSEJ5lXIF1O1p74lv4WF2Y5MNQapEqrO0EQDLW7dvC', '6Psy7UvzhgpcqhdBsKnW3YetGSF3aJMl4SQWr6QRpKvMpj7ul2tjuX0iVAlA', '2022-10-16 21:01:20', '2022-11-17 02:33:39', NULL),
(6, 'Cao Gia Bảo', 'baobeo317@gmail.com', NULL, '$2y$10$MEjC2vD7TA16dKduuP/TiOs1cozKLVhu5QH6kWHTseE10WCevkXXa', NULL, '2022-10-17 06:46:52', '2022-10-17 06:46:52', NULL),
(7, 'Cao Gia Bảo', 'baose317@gmail.com', NULL, '$2y$10$VZhPNnSll4RGrQDPPpnpIOJRf8O3Td.NYEwH0ZLXwctiVMrMTlqx.', NULL, '2022-10-17 06:58:19', '2022-11-02 20:00:59', NULL),
(8, 'Cao Gia Bảo', 'baobeo3172008@gmail.com', NULL, '$2y$10$VLU.7CBFCsatBP4lrA5CZ.LCL4HOwzSz/J.XWn87JXB7gVjNCi/tG', NULL, '2022-10-17 07:00:17', '2022-11-02 20:01:08', NULL),
(9, 'Cao Giao Bảo', 'bao317@gmail.com', NULL, '$2y$10$zYymrmo0MWPjQ3qOiYssI./e2ojzKojPOuSh1dS1bkwW7wmtCRuoG', NULL, '2022-10-17 07:02:38', '2022-11-02 20:01:13', NULL),
(11, 'Cao Gia Bảo', 'admin@gmail.com', NULL, '$2y$10$2dn/eeXFotBXdZFBIAV/BupZgrWi5cGMOk1efjiESl9Kz6yJffoLu', NULL, '2022-10-19 00:54:20', '2022-10-19 00:54:20', NULL),
(13, 'Cao Hải', 'admin1@gmail.com', NULL, '$2y$10$pu8OcgPNqgwjZT1d5kSBMendsWyYiHmtme/BW/YnMiwy8VlHGnD6a', NULL, '2022-10-19 00:54:40', '2022-10-19 00:54:40', NULL),
(14, 'Bảo', 'admin2@gmail.com', NULL, '$2y$10$TPW3lMJxoi6CmwGXhGDt.OTZE4slJ2evdo5846/0/VugIFtsWi64u', NULL, '2022-10-19 00:55:00', '2022-11-02 20:01:22', NULL),
(15, 'Bảo Sề', 'admin3@gmail.com', NULL, '$2y$10$UU.NKxejzQB1kBtt1lbzhe0OiRme.wUECe.cvSg21alfGkVoSIEKy', NULL, '2022-10-19 00:55:26', '2022-10-27 08:02:16', NULL),
(16, 'Cao Gia Bảo', 'baobeo2008@gmail.com', NULL, '$2y$10$5aXJeAuF1hoQpZdc3ZzRV.yE19OnuDvB7UfDoEmVEG.GpQFOALdZu', NULL, '2022-11-02 19:50:10', '2022-11-02 19:50:10', NULL),
(17, 'Cao Gia Bảo Béo Sề', 'bao2008@gmail.com', NULL, '$2y$10$znsVh30hgrRiAlSDMZQG4edDGSf9Ro9n7YoRLNIgr7r/3Y9awPnjC', NULL, '2022-11-03 02:04:30', '2022-11-03 02:09:28', NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `category_products`
--
ALTER TABLE `category_products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `gallerys`
--
ALTER TABLE `gallerys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gallerys_product_id_foreign` (`product_id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `orders_detail`
--
ALTER TABLE `orders_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_detail_order_id_foreign` (`order_id`);

--
-- Chỉ mục cho bảng `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Chỉ mục cho bảng `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_category_post_id_foreign` (`category_post_id`);

--
-- Chỉ mục cho bảng `posts_category`
--
ALTER TABLE `posts_category`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_product_id_foreign` (`category_product_id`),
  ADD KEY `products_user_id_foreign` (`user_id`);

--
-- Chỉ mục cho bảng `product_colors`
--
ALTER TABLE `product_colors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_colors_product_id_foreign` (`product_id`);

--
-- Chỉ mục cho bảng `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Chỉ mục cho bảng `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `category_products`
--
ALTER TABLE `category_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `gallerys`
--
ALTER TABLE `gallerys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT cho bảng `orders_detail`
--
ALTER TABLE `orders_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT cho bảng `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `posts_category`
--
ALTER TABLE `posts_category`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT cho bảng `product_colors`
--
ALTER TABLE `product_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT cho bảng `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `gallerys`
--
ALTER TABLE `gallerys`
  ADD CONSTRAINT `gallerys_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `orders_detail`
--
ALTER TABLE `orders_detail`
  ADD CONSTRAINT `orders_detail_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_post_id_foreign` FOREIGN KEY (`category_post_id`) REFERENCES `posts_category` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_product_id_foreign` FOREIGN KEY (`category_product_id`) REFERENCES `category_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `product_colors`
--
ALTER TABLE `product_colors`
  ADD CONSTRAINT `product_colors_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
